package com.kidmi.videotowebp
import org.junit.Assert.*
import org.junit.Test
import org.json.JSONObject
class StudioFramingTest {
 private fun clip()=StudioClip(uri="content://video/1",name="대상",durationMs=12000,width=1920,height=1080,startMs=2000,endMs=10000,cropEnabled=true,cropZoom=2f)
 @Test fun cropStaysInsideImageAtEveryEdge(){
  for(x in listOf(0f,.5f,1f))for(y in listOf(0f,.5f,1f))for(a in listOf("원본","9:16","16:9","1:1","4:5","3:4")){
   val b=studioCropWindow(clip().copy(focusX=x,focusY=y),a,2000)
   assertTrue(b.left>=0 && b.top>=0);assertTrue(b.left+b.width<=1.00001f);assertTrue(b.top+b.height<=1.00001f)
   assertTrue(b.width>0 && b.height>0)
  }
 }
 @Test fun aspectAndRotationProduceExpectedWindow(){
  val c=clip().copy(cropZoom=1f,rotation=90)
  val b=studioCropWindow(c,"9:16",2000)
  assertEquals(1f,b.width,.0001f);assertEquals(1f,b.height,.0001f)
  val square=studioCropWindow(c.copy(rotation=0),"1:1",2000)
  assertEquals(1080f/1920,square.width,.0001f);assertEquals(1f,square.height,.0001f)
 }
 @Test fun speedAndTrimMapBothDirections(){val c=clip().copy(speed=2f);assertEquals(5000L,c.sourceTime(1500));assertEquals(1500L,c.timelineTime(5000));assertEquals(2000L,c.sourceTime(-5));assertEquals(10000L,c.sourceTime(90000))}
 @Test fun trackingSurvivesSplitAndSpeedChange(){
  val c=clip().copy(speed=2f,autoTrack=listOf(FocusKeyframe(2000,.2f,.3f),FocusKeyframe(10000,.8f,.7f)))
  val (_,right)=c.splitAt(1500)!!
  val original=studioCropWindow(c,"1:1",6500)
  val split=studioCropWindow(right,"1:1",right.sourceTime(750))
  assertEquals(original,split)
  assertEquals(c.autoTrack,right.autoTrack)
 }
 @Test fun manualPointOverridesNearbyAutomaticTracking(){
  val c=clip().copy(autoTrack=listOf(FocusKeyframe(2000,.1f,.1f),FocusKeyframe(6000,.2f,.2f),FocusKeyframe(10000,.3f,.3f)),manualTrack=listOf(FocusKeyframe(6000,.8f,.6f)))
  val value=studioFocus(c.trackingPoints(),6000,.5f,.5f);assertEquals(.8f,value.first,.0001f);assertEquals(.6f,value.second,.0001f)
 }
 @Test fun disabledCropIsFullFrame(){assertEquals(StudioCropWindow(0f,0f,1f,1f),studioCropWindow(clip().copy(cropEnabled=false),"9:16",3000))}
 @Test fun saveRestoresTrackingAndUnifiedOutputOptions(){
  val c=clip().copy(focusX=.3f,trackingMode="SUBJECT",autoTrack=listOf(FocusKeyframe(2000,.2f,.3f)),manualTrack=listOf(FocusKeyframe(3000,.4f,.5f)))
  val p=StudioProject(clips=listOf(c),outputFormat="WebP",webpQuality=67,webpLossless=true,loopForever=false,compression="BALANCED",splitMode="COUNT",splitCount=4,targetPartMb=5,targetTotalMb=12,outputFolder="content://folder/2",exportEachClip=true)
  assertEquals(p,StudioProjectStore.decode(JSONObject(StudioProjectStore.encode(p).toString())))
 }
 @Test fun oldProjectsLoadWithSafeDefaults(){
  val j=StudioProjectStore.encode(StudioProject(clips=listOf(clip())))
  for(k in listOf("outputFormat","webpQuality","exportEachClip","outputFolder"))j.remove(k)
  val c=j.getJSONArray("clips").getJSONObject(0)
  for(k in listOf("cropEnabled","cropZoom","focusX","focusY","trackingMode","autoTrack","manualTrack","sourceFps"))c.remove(k)
  val p=StudioProjectStore.decode(j);assertEquals("MP4",p.outputFormat);assertFalse(p.clips[0].cropEnabled);assertTrue(p.clips[0].autoTrack.isEmpty());assertNull(p.outputFolder)
 }
}
