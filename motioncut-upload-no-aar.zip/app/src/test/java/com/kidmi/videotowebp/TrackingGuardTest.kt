package com.kidmi.videotowebp
import org.junit.Assert.*
import org.junit.Test
class TrackingGuardTest {
 @Test fun acceptsConfidentLocalMotion(){assertTrue(TrackingGuard.accept(.9f,.4f,.5f,.42f,.52f,.06f,.065f,.12f))}
 @Test fun rejectsLowConfidenceAndDifferentAppearance(){assertFalse(TrackingGuard.accept(.3f,.4f,.5f,.42f,.52f,.06f,.065f,.12f));assertFalse(TrackingGuard.accept(.9f,.4f,.5f,.42f,.52f,.06f,.065f,.7f))}
 @Test fun rejectsJumpToAnotherSubject(){assertFalse(TrackingGuard.accept(.99f,.2f,.5f,.7f,.5f,.06f,.06f,0f))}
 @Test fun rejectsInvalidAndSuddenScaleChanges(){assertFalse(TrackingGuard.accept(Float.NaN,.4f,.5f,.42f,.52f,.06f,.065f,.12f));assertFalse(TrackingGuard.accept(.9f,.4f,.5f,.42f,.52f,.06f,.2f,.12f))}
 @Test fun acceptsBoundaryValues(){assertTrue(TrackingGuard.accept(.55f,.4f,.5f,.56f,.5f,.1f,.055f,.48f))}
 @Test fun rejectsOutOfFrameAndZeroArea(){assertFalse(TrackingGuard.accept(.9f,.4f,.5f,1.01f,.5f,.1f,.1f,.1f));assertFalse(TrackingGuard.accept(.9f,.4f,.5f,.5f,.5f,0f,.1f,.1f))}
}
