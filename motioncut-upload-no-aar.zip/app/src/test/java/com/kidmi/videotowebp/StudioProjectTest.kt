package com.kidmi.videotowebp
import org.junit.Assert.*
import org.junit.Test
import org.json.JSONObject
class StudioProjectTest {
 private fun clip()=StudioClip(uri="content://video/1",name="테스트",durationMs=10000,width=1920,height=1080,startMs=1000,endMs=9000)
 @Test fun splitUsesSourceTimeAndPreservesEffects(){
  val c=clip().copy(speed=2f,caption="안녕",brightness=.2f,mirror=true)
  val (a,b)=c.splitAt(1500)!!
  assertEquals(4000L,a.endMs);assertEquals(a.endMs,b.startMs);assertEquals(c.id,a.id);assertNotEquals(a.id,b.id)
  assertEquals(c.caption,b.caption);assertEquals(c.brightness,b.brightness);assertEquals(c.mirror,b.mirror)
  assertEquals(c.outputDurationMs,a.outputDurationMs+b.outputDurationMs)
 }
 @Test fun splitRejectsBoundaries(){val c=clip();assertNull(c.splitAt(0));assertNull(c.splitAt(8000));assertNull(c.splitAt(-20))}
 @Test fun sequenceUsesEditedDurations(){
  val p=StudioProject(clips=listOf(clip().copy(speed=2f),clip().copy(speed=.5f)))
  assertEquals(20000L,p.durationMs);assertEquals(0,p.clipAt(3999));assertEquals(1,p.clipAt(4000));assertEquals(1,p.clipAt(20000));assertEquals(-1,StudioProject().clipAt(0))
 }
 @Test fun canvasSizesAreEvenAndBounded(){for(a in listOf("original","9:16","16:9","1:1","4:5"))for(s in listOf(480,720,1080)){
  val (w,h)=StudioProject(clips=listOf(clip()),aspect=a,maxSide=s).outputSize();assertEquals(s,maxOf(w,h));assertEquals(0,w%2);assertEquals(0,h%2)
 }}
 @Test fun originalCanvasRespectsRotation(){assertEquals(404 to 720,StudioProject(clips=listOf(clip().copy(rotation=90)),aspect="original").outputSize())}
 @Test fun projectRoundTripPreservesEdits(){
  val p=StudioProject(name="내 영상\n고양이",clips=listOf(clip().copy(speed=1.5f,rotation=90,mirror=true,brightness=.2f,contrast=-.2f,saturation=30f,volume=.8f,caption="첫째\n둘째",captionY=.7f,captionSize=1.2f)),aspect="4:5",fillCanvas=true,maxSide=1080,fps=24,music=StudioMusic("content://music/3","음악",30000,.2f),audioFade=true)
  assertEquals(p,StudioProjectStore.decode(JSONObject(StudioProjectStore.encode(p).toString())))
 }
 @Test fun reorderAndDeleteRecalculateTimeline(){
  val a=clip();val b=clip().copy(speed=.5f);val c=clip().copy(speed=2f)
  val p=StudioProject(clips=listOf(c,a,b));assertEquals(4000L,p.clipStart(1));assertEquals(12000L,p.clipStart(2));assertEquals(12000L,p.copy(clips=listOf(c,a)).durationMs)
 }
 @Test fun invalidEditsFailBeforeExport(){for(c in listOf(clip().copy(speed=0f),clip().copy(speed=Float.NaN),clip().copy(startMs=9500),clip().copy(endMs=20000))){
  assertThrows(IllegalArgumentException::class.java){StudioProject(clips=listOf(c)).validate()}
 }}
 @Test fun musicEditRoundTripAndValidation(){
  val music=StudioMusic("content://music/9","bgm",30000,.4f,startMs=1200,trimStartMs=2000,trimEndMs=18000,loop=false)
  val p=StudioProject(clips=listOf(clip()),music=music)
  val decoded=StudioProjectStore.decode(JSONObject(StudioProjectStore.encode(p).toString()))
  assertEquals(music,decoded.music);decoded.validate()
  assertThrows(IllegalArgumentException::class.java){p.copy(music=music.copy(trimEndMs=1000)).validate()}
 }
 @Test fun captionStyleRoundTrip(){
  val c=clip().copy(caption="테스트",captionColor="MINT",captionBackground=false)
  val p=StudioProject(clips=listOf(c));val decoded=StudioProjectStore.decode(JSONObject(StudioProjectStore.encode(p).toString()))
  assertEquals("MINT",decoded.clips[0].captionColor);assertFalse(decoded.clips[0].captionBackground)
 }

}
