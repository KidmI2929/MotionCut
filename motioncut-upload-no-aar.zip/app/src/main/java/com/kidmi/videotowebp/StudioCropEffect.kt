package com.kidmi.videotowebp
import android.graphics.Matrix
import androidx.media3.common.util.Size
import androidx.media3.effect.MatrixTransformation
import kotlin.math.roundToInt

/** Media3 effects receive composition time after trim/speed adjustment. */
class StudioCropEffect(private val clip:StudioClip,private val aspect:String,private val clipStartMs:Long):MatrixTransformation {
 private val points=clip.trackingPoints()
 private val matrix=Matrix()
 override fun configure(inputWidth:Int,inputHeight:Int):Size{
  val box=studioCropWindow(clip,aspect,clip.startMs,points)
  return Size((inputWidth*box.width).roundToInt().coerceAtLeast(2),(inputHeight*box.height).roundToInt().coerceAtLeast(2))
 }
 override fun getMatrix(presentationTimeUs:Long):Matrix{
  val time=clip.sourceTime(presentationTimeUs/1000-clipStartMs)
  val box=studioCropWindow(clip,aspect,time,points)
  val centerX=2*(box.left+box.width/2)-1
  val centerY=1-2*(box.top+box.height/2)
  matrix.reset();matrix.postTranslate(-centerX,-centerY);matrix.postScale(1/box.width,1/box.height)
  return matrix
 }
}
