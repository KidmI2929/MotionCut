package com.kidmi.videotowebp
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
object StudioProjectStore {
 private fun folder(c:Context)=File(c.filesDir,"motioncut_projects").apply{mkdirs()}
 @Synchronized fun save(c:Context,p:StudioProject){
  require(p.id.matches(Regex("[a-zA-Z0-9-]+")))
  val atomic=android.util.AtomicFile(File(folder(c),"${p.id}.json"));val stream=atomic.startWrite()
  try{stream.write(encode(p).toString().toByteArray(Charsets.UTF_8));atomic.finishWrite(stream)}catch(e:Exception){atomic.failWrite(stream);throw e}
 }
 fun list(c:Context):List<StudioProject> = folder(c).listFiles().orEmpty().filter{it.extension=="json"}.sortedByDescending{it.lastModified()}.mapNotNull{file->
  runCatching{decode(JSONObject(file.readText()))}.getOrElse{
   // Keep a corrupt project for diagnostics/recovery, but do not parse it on every launch.
   runCatching{file.renameTo(File(file.parentFile,file.nameWithoutExtension+".corrupt.json"))}
   null
  }
 }
 @Synchronized fun delete(c:Context,p:StudioProject):Boolean {
  require(p.id.matches(Regex("[a-zA-Z0-9-]+")))
  val file=File(folder(c),"${p.id}.json")
  return !file.exists() || file.delete()
 }
 fun encode(p:StudioProject)=JSONObject().apply{
  put("schema",2);put("id",p.id);put("name",p.name);put("aspect",p.aspect);put("fill",p.fillCanvas);if(p.maxSide==null)put("maxSide",JSONObject.NULL) else put("maxSide",p.maxSide);put("fps",p.fps);put("fade",p.audioFade)
  put("outputFormat",p.outputFormat);put("webpQuality",p.webpQuality);put("webpLossless",p.webpLossless);put("loopForever",p.loopForever);put("compression",p.compression);put("splitMode",p.splitMode);put("splitCount",p.splitCount);put("targetPartMb",p.targetPartMb);put("targetTotalMb",p.targetTotalMb);put("outputFolder",p.outputFolder);put("exportEachClip",p.exportEachClip)
  put("clips",JSONArray().apply{p.clips.forEach{c->put(JSONObject().apply{
   put("id",c.id);put("uri",c.uri);put("name",c.name);put("duration",c.durationMs);put("width",c.width);put("height",c.height);put("start",c.startMs);put("end",c.endMs);put("speed",c.speed);put("rotation",c.rotation);put("mirror",c.mirror);put("brightness",c.brightness);put("contrast",c.contrast);put("saturation",c.saturation);put("volume",c.volume);put("caption",c.caption);put("captionY",c.captionY);put("captionSize",c.captionSize);put("captionColor",c.captionColor);put("captionBackground",c.captionBackground)
   put("targetSize",c.targetSize);put("targetSelected",c.targetSelected);put("sourceFps",c.sourceFps);put("cropEnabled",c.cropEnabled);put("cropZoom",c.cropZoom);put("focusX",c.focusX);put("focusY",c.focusY);put("trackingMode",c.trackingMode)
   fun points(list:List<FocusKeyframe>)=JSONArray().apply{list.forEach{put(JSONArray().put(it.timeMs).put(it.x).put(it.y))}}
   put("autoTrack",points(c.autoTrack));put("manualTrack",points(c.manualTrack))
  })}})
  p.music?.let{m->put("music",JSONObject().apply{put("uri",m.uri);put("name",m.name);put("duration",m.durationMs);put("volume",m.volume);put("startMs",m.startMs);put("trimStartMs",m.trimStartMs);put("trimEndMs",m.trimEndMs);put("loop",m.loop)})}
 }
 private fun readPoints(a:JSONArray?):List<FocusKeyframe> = if(a==null)emptyList() else List(a.length()){val p=a.getJSONArray(it);FocusKeyframe(p.getLong(0),p.getDouble(1).toFloat(),p.getDouble(2).toFloat())}
 fun decode(j:JSONObject):StudioProject{
  require(j.optInt("schema") in 1..2);val clips=j.getJSONArray("clips")
  return StudioProject(j.getString("id"),j.getString("name"),List(clips.length()){i->val c=clips.getJSONObject(i)
   StudioClip(c.getString("id"),c.getString("uri"),c.getString("name"),c.getLong("duration"),c.getInt("width"),c.getInt("height"),c.getLong("start"),c.getLong("end"),c.getDouble("speed").toFloat(),c.getInt("rotation"),c.getBoolean("mirror"),c.getDouble("brightness").toFloat(),c.getDouble("contrast").toFloat(),c.getDouble("saturation").toFloat(),c.getDouble("volume").toFloat(),c.getString("caption"),c.getDouble("captionY").toFloat(),c.optDouble("captionSize",1.0).toFloat(),
    c.optBoolean("cropEnabled"),c.optDouble("cropZoom",1.0).toFloat(),c.optDouble("focusX",.5).toFloat(),c.optDouble("focusY",.5).toFloat(),c.optString("trackingMode","SUBJECT"),readPoints(c.optJSONArray("autoTrack")),readPoints(c.optJSONArray("manualTrack")),c.optDouble("sourceFps",30.0).toFloat(),c.optDouble("targetSize",.24).toFloat(),c.optBoolean("targetSelected"),c.optString("captionColor","WHITE"),c.optBoolean("captionBackground",true))
  },j.getString("aspect"),j.getBoolean("fill"),if(j.isNull("maxSide"))null else j.optInt("maxSide",720),j.getInt("fps"),j.optJSONObject("music")?.let{StudioMusic(it.getString("uri"),it.getString("name"),it.getLong("duration"),it.getDouble("volume").toFloat(),it.optLong("startMs",0),it.optLong("trimStartMs",0),it.optLong("trimEndMs",it.getLong("duration")),it.optBoolean("loop",true))},j.optBoolean("fade"),j.optString("outputFormat","MP4"),j.optInt("webpQuality",80),j.optBoolean("webpLossless"),j.optBoolean("loopForever",true),j.optString("compression","FAST"),j.optString("splitMode","NONE"),j.optInt("splitCount",2),j.optInt("targetPartMb",8),j.optInt("targetTotalMb",0),j.optString("outputFolder").takeIf{it.isNotBlank() && it!="null"},j.optBoolean("exportEachClip"))
 }
}
