package com.kidmi.videotowebp

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.io.File

object CrashDiagnostics {
    private var installed = false
    fun install(context: Context) {
        if (installed) return
        installed = true
        val reportFile = File(context.filesDir, "last-crash.txt")
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching {
                reportFile.writeText("MotionCut 2.2.0\nAndroid ${Build.VERSION.RELEASE}\n${Build.MANUFACTURER} ${Build.MODEL}\nThread: ${thread.name}\n${error.stackTraceToString().take(16000)}")
            }
            if (previous != null) previous.uncaughtException(thread, error)
            else android.os.Process.killProcess(android.os.Process.myPid())
        }
    }

    fun read(context: Context): String? {
        val file = File(context.filesDir, "last-crash.txt")
        if (file.exists()) return runCatching { file.readText().take(16000) }.getOrNull()
        if (Build.VERSION.SDK_INT < 30) return null
        return runCatching {
            val preferences = context.getSharedPreferences("diagnostics", Context.MODE_PRIVATE)
            val exit = (context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager)
                .getHistoricalProcessExitReasons(null, 0, 1).firstOrNull() ?: return@runCatching null
            if (exit.timestamp <= preferences.getLong("seen_exit", 0)) return@runCatching null
            preferences.edit().putLong("seen_exit", exit.timestamp).apply()
            if (exit.reason !in listOf(ApplicationExitInfo.REASON_CRASH, ApplicationExitInfo.REASON_CRASH_NATIVE,
                    ApplicationExitInfo.REASON_ANR, ApplicationExitInfo.REASON_LOW_MEMORY)) return@runCatching null
            "Android ${Build.VERSION.RELEASE} · ${Build.MANUFACTURER} ${Build.MODEL}\n종료 사유 코드: ${exit.reason}\n${exit.description.orEmpty()}"
        }.getOrNull()
    }
}

@Composable
fun CrashDiagnosticDialog() {
    val context = LocalContext.current
    var report by remember { mutableStateOf(CrashDiagnostics.read(context)) }
    var copied by remember { mutableStateOf(false) }
    report?.let { text ->
        AlertDialog(
            onDismissRequest = { report = null },
            title = { Text("이전 실행의 오류 기록") },
            text = { Text("아래 기록을 복사해 보내주시면 종료 원인을 확인하는 데 도움이 됩니다.\n\n$text",
                modifier = Modifier.heightIn(max = 300.dp).verticalScroll(rememberScrollState())) },
            confirmButton = { TextButton(onClick = {
                (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("MotionCut 오류", text))
                copied = true
            }) { Text(if (copied) "복사됨" else "오류 복사") } },
            dismissButton = { TextButton(onClick = {
                File(context.filesDir, "last-crash.txt").delete()
                report = null
            }) { Text("닫기") } }
        )
    }
}
