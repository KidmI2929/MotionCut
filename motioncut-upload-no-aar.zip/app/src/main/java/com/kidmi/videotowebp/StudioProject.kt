package com.kidmi.videotowebp
import java.util.UUID
import kotlin.math.roundToLong

data class StudioClip(
 val id:String=UUID.randomUUID().toString(), val uri:String, val name:String,
 val durationMs:Long, val width:Int, val height:Int, val startMs:Long=0, val endMs:Long=durationMs,
 val speed:Float=1f,val rotation:Int=0,val mirror:Boolean=false,
 val brightness:Float=0f,val contrast:Float=0f,val saturation:Float=0f,val volume:Float=1f,
 val caption:String="",val captionY:Float=-.7f,val captionSize:Float=1f,
 val cropEnabled:Boolean=false,val cropZoom:Float=1f,val focusX:Float=.5f,val focusY:Float=.5f,
 val trackingMode:String="SUBJECT",val autoTrack:List<FocusKeyframe> = emptyList(),val manualTrack:List<FocusKeyframe> = emptyList(),val sourceFps:Float=30f,val targetSize:Float=.24f,val targetSelected:Boolean=false,
 val captionColor:String="WHITE",val captionBackground:Boolean=true
) {
 val outputDurationMs:Long get()=((endMs-startMs)/speed.toDouble()).roundToLong().coerceAtLeast(1)
 fun splitAt(offset:Long):Pair<StudioClip,StudioClip>? {
  val time=startMs+(offset*speed).roundToLong()
  if(time-startMs<100 || endMs-time<100)return null
  return copy(endMs=time) to copy(id=UUID.randomUUID().toString(),startMs=time)
 }
}
data class StudioMusic(val uri:String,val name:String,val durationMs:Long,val volume:Float=.35f,val startMs:Long=0,val trimStartMs:Long=0,val trimEndMs:Long=durationMs,val loop:Boolean=true) {
 val playDurationMs:Long get()=(trimEndMs-trimStartMs).coerceAtLeast(1)
}
data class StudioProject(
 val id:String=UUID.randomUUID().toString(),val name:String="새 프로젝트",val clips:List<StudioClip> = emptyList(),
 val aspect:String="9:16",val fillCanvas:Boolean=false,val maxSide:Int?=720,val fps:Int=30,
 val music:StudioMusic?=null,val audioFade:Boolean=false,
 val outputFormat:String="MP4",val webpQuality:Int=80,val webpLossless:Boolean=false,val loopForever:Boolean=true,
 val compression:String="FAST",val splitMode:String="NONE",val splitCount:Int=2,val targetPartMb:Int=8,
 val targetTotalMb:Int=0,val outputFolder:String?=null,val exportEachClip:Boolean=false
) {
 val durationMs:Long get()=clips.sumOf {it.outputDurationMs}
 fun clipStart(index:Int)=clips.take(index.coerceAtLeast(0)).sumOf {it.outputDurationMs}
 fun clipAt(time:Long):Int {var sum=0L;clips.forEachIndexed {i,c->sum+=c.outputDurationMs;if(time<sum)return i};return clips.lastIndex}
 fun outputSize():Pair<Int,Int> {
  val c=clips.firstOrNull()
  val ratio=studioAspectRatio(aspect,c).coerceIn(.1,10.0)
  val sourceLong=clips.maxOfOrNull { clip -> if (clip.rotation % 180 == 0) maxOf(clip.width,clip.height) else maxOf(clip.height,clip.width) }?.coerceAtLeast(2) ?: 720
  val side=(maxSide ?: sourceLong).coerceIn(2,2160)
  fun even(n:Double)=((n.toInt()/2)*2).coerceAtLeast(2)
  return if(ratio>=1)side to even(side/ratio) else even(side*ratio) to side
 }
 fun validate() {
  require(clips.isNotEmpty()){ "영상을 추가해 주세요." };require(clips.size<=30){"최대 30개 클립까지 추가할 수 있습니다."}
  clips.forEach {c->
   require(c.durationMs>0 && c.width>0 && c.height>0){"영상 정보를 확인해 주세요: ${c.name}"}
   require(c.startMs>=0 && c.endMs<=c.durationMs && c.endMs-c.startMs>=100){"구간을 확인해 주세요: ${c.name}"}
   require(c.speed.isFinite() && c.speed in .25f..4f){"속도는 0.25~4배로 설정해 주세요."}
   require(c.targetSize.isFinite() && c.targetSize in .08f..0.65f)
   require(c.cropZoom.isFinite() && c.cropZoom in 1f..4f)
   require(c.focusX.isFinite() && c.focusY.isFinite() && c.focusX in 0f..1f && c.focusY in 0f..1f)
   (c.autoTrack+c.manualTrack).forEach { require(it.timeMs>=0 && it.x.isFinite() && it.y.isFinite() && it.x in 0f..1f && it.y in 0f..1f) }
   require(c.volume.isFinite() && c.volume in 0f..1f)
   require(c.brightness.isFinite() && c.brightness in -0.5f..0.5f)
   require(c.contrast.isFinite() && c.contrast in -0.5f..0.5f)
   require(c.saturation.isFinite() && c.saturation in -100f..100f)
  }
  require(durationMs<=3_600_000){"60분 이내로 내보내 주세요."}
  music?.let { require(it.durationMs>0 && it.volume in 0f..1f); require(it.startMs>=0); require(it.trimStartMs>=0 && it.trimEndMs<=it.durationMs && it.trimEndMs>it.trimStartMs) }
 }
}
