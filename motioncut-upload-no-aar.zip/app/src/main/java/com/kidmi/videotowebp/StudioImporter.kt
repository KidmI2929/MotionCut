package com.kidmi.videotowebp
import android.content.Context
import android.net.Uri
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File
import java.util.UUID

/** Runs on the import IO dispatcher. Persist normalized media with the project, not in cache. */
object StudioImporter {
 fun prepare(context:Context,source:Uri):Pair<Uri,VideoInfo>{
  val original=runCatching{readVideoInfo(context,source)}.getOrNull()
  val name=queryDisplayName(context,source) ?: "영상"
  val extension=name.substringAfterLast('.',"").lowercase()
  if(original!=null && original.durationMs>=100 && original.width>0 && original.height>0 && extension !in setOf("avi","flv","wmv","gif"))return source to original
  val folder=File(context.filesDir,"imported_media").apply{mkdirs()}
  val file=File(folder,"${UUID.randomUUID()}.mp4")
  val input=if(source.scheme=="file")requireNotNull(source.path) else FFmpegKitConfig.getSafParameterForRead(context,source)
  try{
   // First attempt a lossless container change; unsupported video/audio codecs use the compatibility path.
   var result=FFmpegKit.executeWithArguments(arrayOf("-hide_banner","-loglevel","error","-nostdin","-y","-i",input,"-map","0:v:0","-map","0:a?","-c","copy",file.absolutePath))
   var info=if(ReturnCode.isSuccess(result.returnCode))runCatching{readVideoInfo(context,Uri.fromFile(file))}.getOrNull() else null
   if(info==null || info.width<=0 || info.height<=0 || info.durationMs<100){
    result=FFmpegKit.executeWithArguments(arrayOf("-hide_banner","-loglevel","error","-nostdin","-y","-threads","2","-i",input,"-map","0:v:0","-map","0:a?","-vf","scale='min(1920,iw)':-2","-c:v","mpeg4","-q:v","3","-pix_fmt","yuv420p","-c:a","aac","-b:a","160k","-movflags","+faststart",file.absolutePath))
    require(ReturnCode.isSuccess(result.returnCode)){"이 파일의 코덱을 호환 변환하지 못했습니다."}
    info=readVideoInfo(context,Uri.fromFile(file))
   }
   requireNotNull(info)
   require(info.durationMs>=100 && info.width>0 && info.height>0){"영상 정보를 읽을 수 없습니다."}
   return Uri.fromFile(file) to info.copy(displayName=name)
  }catch(e:Throwable){file.delete();throw e}
 }
}
