package com.kidmi.videotowebp

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.Player
import androidx.media3.common.PlaybackException
import androidx.media3.transformer.CompositionPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.ui.AspectRatioFrameLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.UUID
import kotlin.math.roundToInt
import kotlin.math.roundToLong

private val Mint=Color(0xFF83F0D1)
private val Panel=Color(0xFF1B2029)
private val Muted=Color(0xFFA5ADBC)
private val thumbnailMutex=Mutex()

@Composable
fun MotionCutStudio(onOpenWebPConverter:()->Unit = {}){
 val context=LocalContext.current;val scope=rememberCoroutineScope()
 var project by remember{mutableStateOf<StudioProject?>(null)}
 var projects by remember{mutableStateOf<List<StudioProject>>(emptyList())}
 var selected by remember{mutableIntStateOf(0)}
 var tool by remember{mutableStateOf("컷 편집")}
 var position by remember{mutableLongStateOf(0)}
 var loading by remember{mutableStateOf(false)}
 var busy by remember{mutableStateOf(false)}
 var progress by remember{mutableFloatStateOf(0f)}
 var status by remember{mutableStateOf("")}
 var error by remember{mutableStateOf<String?>(null)}
 var result by remember{mutableStateOf<List<StudioOutput>?>(null)}
 var analyzing by remember{mutableStateOf(false)}
 var rawFraming by remember{mutableStateOf(false)}
 var gestures by remember{mutableStateOf(false)}
 var exportRequest by remember{mutableStateOf<StudioProject?>(null)}
 val tracker=remember{FaceTrackingAnalyzer(context.applicationContext)}
 val deepTracker=remember{DeepTrackingAnalyzer(context.applicationContext)}
 var showExport by remember{mutableStateOf(false)}
 var showRatio by remember{mutableStateOf(false)}
 var showRename by remember{mutableStateOf(false)}
 var undo by remember{mutableStateOf<List<StudioProject>>(emptyList())}
 var redo by remember{mutableStateOf<List<StudioProject>>(emptyList())}
 var lastEdit by remember{mutableLongStateOf(0)}
 var player by remember{mutableStateOf<CompositionPlayer?>(null)}
 var playing by remember{mutableStateOf(false)}
 var deleteRequest by remember{mutableStateOf<StudioProject?>(null)}
 val exporter=remember{StudioExporter(context.applicationContext)}
 val lifecycle=LocalLifecycleOwner.current.lifecycle
 fun update(next:StudioProject,coalesce:Boolean=false){
  val old=project ?: return;if(old==next)return;val now=android.os.SystemClock.elapsedRealtime()
  if(!coalesce || now-lastEdit>600)undo=(undo+old).takeLast(30)
  lastEdit=now;redo=emptyList();project=next;result=null
  selected=selected.coerceIn(0,(next.clips.size-1).coerceAtLeast(0));position=position.coerceIn(0,next.durationMs)
 }
 fun change(c:StudioClip,coalesce:Boolean=false){val p=project ?: return;update(p.copy(clips=p.clips.map{if(it.id==c.id)c else it}),coalesce)}
 fun open(p:StudioProject){player?.pause();project=p;selected=0;position=0;undo=emptyList();redo=emptyList();result=null;status=""}
 fun seek(ms:Long){position=ms.coerceIn(0,project?.durationMs ?: 0);player?.seekTo(position)}
 fun home(){val p=project ?: return;player?.pause();scope.launch{try{withContext(Dispatchers.IO){StudioProjectStore.save(context,p)};project=null;projects=withContext(Dispatchers.IO){StudioProjectStore.list(context)}}catch(e:Exception){error="프로젝트 저장 실패: ${e.message}"}}}
 LaunchedEffect(exportRequest){val request=exportRequest ?: return@LaunchedEffect
  // Launched after the composition commits: preview resources have been released by busy=true.
  exporter.export(request,{status=it},{progress=it},{result=it;busy=false;exportRequest=null;status="저장 완료"},{error=it;busy=false;exportRequest=null})
 }
 LaunchedEffect(Unit){projects=withContext(Dispatchers.IO){StudioProjectStore.list(context)}}
 LaunchedEffect(project){val p=project ?: return@LaunchedEffect;delay(650);try{withContext(Dispatchers.IO){StudioProjectStore.save(context,p)}}catch(e:Exception){error="자동 저장 실패: ${e.message}"}}
 DisposableEffect(lifecycle){val observer=LifecycleEventObserver{_,event->if(event==Lifecycle.Event.ON_STOP)player?.pause()};lifecycle.addObserver(observer);onDispose{lifecycle.removeObserver(observer);exporter.cancel();tracker.cancel();deepTracker.cancel()}}
 DisposableEffect(busy){val w=(context as? Activity)?.window;if(busy)w?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);onDispose{w?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)}}
 BackHandler(project!=null){if(!busy && !loading && !analyzing)home()}
 val videoPicker=rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()){uris->
  if(uris.isNotEmpty()){
   val base=project ?: StudioProject(name="프로젝트 ${projects.size+1}");loading=true
   scope.launch{try{
    val(loaded,failed)=withContext(Dispatchers.IO){val clips=mutableListOf<StudioClip>();var failures=0
     for(uri in uris.take((30-base.clips.size).coerceAtLeast(0)))try{
      runCatching{context.contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}
      val (preparedUri,i)=StudioImporter.prepare(context,uri);require(i.durationMs>=100 && i.width>0 && i.height>0)
      clips+=StudioClip(uri=preparedUri.toString(),name=i.displayName,durationMs=i.durationMs,width=i.width,height=i.height,sourceFps=i.sourceFps ?: 30f)
     }catch(e:Exception){failures++};clips.toList() to failures
    }
    if(loaded.isNotEmpty()){val next=base.copy(clips=base.clips+loaded);if(project==null)open(next) else update(next);selected=base.clips.size}
    if(failed>0)error="${failed}개 영상을 읽을 수 없습니다. 다른 파일을 선택해 주세요."
    if(uris.size>30-base.clips.size)status="최대 30개 클립까지 추가했습니다."
   }finally{loading=false}}
  }
 }
 val musicPicker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->
  val p=project;if(uri!=null && p!=null){loading=true;scope.launch{try{
   val m=withContext(Dispatchers.IO){runCatching{context.contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)};val r=MediaMetadataRetriever();try{r.setDataSource(context,uri);val d=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0;require(d>0);StudioMusic(uri.toString(),queryDisplayName(context,uri) ?: "배경음악",d)}finally{r.release()}}
   update(p.copy(music=m))
  }catch(e:Exception){error="음악 불러오기 실패: ${e.message}"}finally{loading=false}}}
 }
 Surface(color=Color(0xFF0D1016),modifier=Modifier.fillMaxSize()){
  Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()){
   val p=project
   Row(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically){
    if(p!=null)TextButton(onClick={home()},enabled=!busy && !loading && !analyzing){Text("‹ 프로젝트",color=Mint)}
    Column(Modifier.weight(1f)){
     Text(if(p==null)"MotionCut" else p.name,fontSize=if(p==null)27.sp else 16.sp,fontWeight=FontWeight.Bold,color=Color.White,maxLines=1,overflow=TextOverflow.Ellipsis,modifier=Modifier.clickable(enabled=p!=null && !busy){showRename=true})
     if(p==null)Text("CREATE / FRAME / EXPORT · 2.3",fontSize=12.sp,color=Muted)
    }
    if(p==null)Surface(color=Panel,shape=RoundedCornerShape(8.dp)){Text("STUDIO",Modifier.padding(10.dp),color=Mint,fontSize=11.sp)}
    else Button(onClick={player?.pause();showExport=true},enabled=p.clips.isNotEmpty() && !busy && !loading && !analyzing,colors=ButtonDefaults.buttonColors(containerColor=Mint,contentColor=Color(0xFF08271F))){Text("내보내기")}
   }
   if(p==null){
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(20.dp),verticalArrangement=Arrangement.spacedBy(18.dp)){
     Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Brush.linearGradient(listOf(Color(0xFF244D49),Color(0xFF343056)))).padding(24.dp)){
      Column(verticalArrangement=Arrangement.spacedBy(16.dp)){
       Text("장면을 모아,\n하나의 이야기로.",fontSize=30.sp,lineHeight=38.sp,fontWeight=FontWeight.Bold,color=Color.White)
       Text("컷 · 크롭 · 추적 · 음악, 하나의 편집 흐름",color=Color(0xFFD4E3E0),fontSize=14.sp)
       Button(onClick={videoPicker.launch(arrayOf("video/*","image/gif","application/octet-stream"))},enabled=!loading,colors=ButtonDefaults.buttonColors(containerColor=Mint,contentColor=Color(0xFF08271F))){Text("＋ 새 프로젝트",fontWeight=FontWeight.Bold)}
      }
     }
     Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
      Text("내 프로젝트",fontSize=20.sp,fontWeight=FontWeight.SemiBold,color=Color.White,modifier=Modifier.weight(1f))
      OutlinedButton(onClick=onOpenWebPConverter){Text("WebP 변환기")}
     }
     if(projects.isEmpty())Text("편집 내용은 자동으로 저장됩니다. 원본 영상을 삭제하거나 옮기면 프로젝트에서 다시 열지 못할 수 있습니다.",color=Muted,fontSize=14.sp)
     projects.forEach{saved->Surface(color=Panel,shape=RoundedCornerShape(16.dp),modifier=Modifier.fillMaxWidth().clickable{open(saved)}){
      Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Text("▶",color=Mint,fontSize=24.sp,modifier=Modifier.padding(end=16.dp));Column(Modifier.weight(1f)){Text(saved.name,color=Color.White,fontWeight=FontWeight.SemiBold);Text("${saved.clips.size}개 클립 · ${formatDuration(saved.durationMs)} · ${saved.aspect}",color=Muted,fontSize=12.sp)};TextButton(onClick={deleteRequest=saved}){Text("삭제",color=Color(0xFFFFB5B9))};Text("열기 ›",color=Mint)}
     }}
     Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){
      listOf("01" to "컷을 고르고", "02" to "대상을 따라", "03" to "원하는 포맷으로").forEach{(number,label)->
       Surface(color=Panel,shape=RoundedCornerShape(14.dp),modifier=Modifier.weight(1f)){Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text(number,color=Mint,fontSize=12.sp);Text(label,color=Color.White,fontSize=12.sp)}}
      }
     }
     Text("MP4 · MOV · MKV · WebM 등 불러오기\n크롭·추적 후 MP4 · MOV · MKV · WebP · GIF로 저장",color=Muted,fontSize=12.sp)

    }
   }else{
    val enabled=!busy && !loading && !analyzing
    val selectedClip=p.clips.getOrNull(selected)
    val sourceMs=selectedClip?.sourceTime(position-p.clipStart(selected)) ?: 0
    val framingTool=tool=="크롭" || tool=="추적"
    if(framingTool){Row(Modifier.fillMaxWidth().padding(horizontal=16.dp),verticalAlignment=Alignment.CenterVertically){
     Text(if(rawFraming)"FRAME  /  원본에서 지정" else "PREVIEW  /  편집 결과",color=Muted,fontSize=10.sp,modifier=Modifier.weight(1f))
     TextButton(onClick={player?.pause();rawFraming=!rawFraming},enabled=enabled){Text(if(rawFraming)"결과 미리보기 →" else "원본에서 조정",color=Mint,fontSize=12.sp)}
    }}
    if(framingTool && rawFraming && selectedClip!=null && !busy){
     val c=selectedClip
     val frameHeight=(LocalConfiguration.current.screenHeightDp*.25f).coerceIn(130f,240f).dp
     StudioFramingPreview(c,p.aspect,sourceMs,gestures && enabled,frameHeight,{x,y->if(enabled){
      val manual=if(c.autoTrack.isNotEmpty() || c.manualTrack.isNotEmpty())(c.manualTrack.filterNot{kotlin.math.abs(it.timeMs-sourceMs)<80}+FocusKeyframe(sourceMs,x,y)).sortedBy{it.timeMs} else c.manualTrack
      change(c.copy(cropEnabled=true,focusX=x,focusY=y,targetSelected=true,manualTrack=manual),true)
     }},{z->if(enabled)change(c.copy(cropEnabled=true,cropZoom=z),true)})
    }else StudioPreview(p,busy || analyzing,position,{player=it},{position=it},{playing=it},{error=it})
    Row(Modifier.fillMaxWidth().padding(horizontal=12.dp),verticalAlignment=Alignment.CenterVertically){
     TextButton(onClick={if(framingTool && rawFraming){rawFraming=false;status="편집 결과 미리보기로 전환했습니다. 재생을 눌러 확인하세요."}else if(playing)player?.pause() else{if(position>=p.durationMs-80)seek(0);player?.play()}},enabled=enabled && p.clips.isNotEmpty()){Text(if(framingTool && rawFraming)"▶ 결과 보기" else if(playing)"Ⅱ 일시정지" else "▶ 재생",color=Mint)}
     Text("${formatDetailedTime(position)} / ${formatDuration(p.durationMs)}",color=Muted,fontSize=11.sp,modifier=Modifier.weight(1f))
     TextButton(onClick={redo=(redo+p).takeLast(30);project=undo.last();undo=undo.dropLast(1);selected=0;result=null},enabled=enabled && undo.isNotEmpty()){Text("↶",fontSize=23.sp)}
     TextButton(onClick={undo=(undo+p).takeLast(30);project=redo.last();redo=redo.dropLast(1);selected=0;result=null},enabled=enabled && redo.isNotEmpty()){Text("↷",fontSize=23.sp)}
    }
    Slider(value=position.toFloat().coerceIn(0f,p.durationMs.coerceAtLeast(1).toFloat()),onValueChange={player?.pause();seek(it.toLong())},valueRange=0f..p.durationMs.coerceAtLeast(1).toFloat(),enabled=enabled,modifier=Modifier.fillMaxWidth().height(26.dp).padding(horizontal=20.dp))
    LazyRow(Modifier.fillMaxWidth().padding(vertical=8.dp),contentPadding=PaddingValues(horizontal=16.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)){
     itemsIndexed(p.clips,key={_,c->c.id}){index,c->val active=index==selected
      Column(Modifier.width((c.outputDurationMs/1000f*18).coerceIn(148f,320f).dp).clip(RoundedCornerShape(10.dp)).border(if(active)2.dp else 1.dp,if(active)Mint else Color(0xFF39414E),RoundedCornerShape(10.dp)).background(Panel).clickable(enabled=enabled){selected=index;player?.pause();seek(p.clipStart(index))}.padding(5.dp)){
       Box(Modifier.fillMaxWidth().height(44.dp)){
        StudioFrames(c,4,c.sourceTime(position-p.clipStart(index)),{t->selected=index;player?.pause();seek(p.clipStart(index)+c.timelineTime(t))},Modifier.fillMaxSize(),compact=true,enabled=enabled)
        if(position in p.clipStart(index)..(p.clipStart(index)+c.outputDurationMs))Canvas(Modifier.fillMaxSize()){
         val x=((position-p.clipStart(index)).toFloat()/c.outputDurationMs).coerceIn(0f,1f)*size.width
         drawLine(Color.White,androidx.compose.ui.geometry.Offset(x,0f),androidx.compose.ui.geometry.Offset(x,size.height),2.dp.toPx())
        }
       };Text("${index+1} · ${"%.1f".format(c.outputDurationMs/1000f)}초",fontSize=11.sp,color=if(active)Mint else Color.White,modifier=Modifier.padding(top=3.dp))
      }
     }
     item{OutlinedButton(onClick={videoPicker.launch(arrayOf("video/*","image/gif","application/octet-stream"))},enabled=enabled && p.clips.size<30,modifier=Modifier.height(70.dp)){Text("＋ 영상")}}
    }
    p.music?.let{Text("♫ ${it.name} · 반복 재생",modifier=Modifier.fillMaxWidth().background(Color(0xFF283140)).padding(horizontal=18.dp,vertical=5.dp),fontSize=11.sp,color=Color(0xFFB8C9FF),maxLines=1,overflow=TextOverflow.Ellipsis)}
    LazyRow(contentPadding=PaddingValues(horizontal=14.dp),horizontalArrangement=Arrangement.spacedBy(7.dp)){
     itemsIndexed(listOf("컷 편집","크롭","추적","속도","색 보정","글자","오디오")){_,label->FilterChip(selected=tool==label,onClick={player?.pause();tool=label;rawFraming=label=="크롭" || label=="추적"},leadingIcon={StudioGlyph(label,color=if(tool==label)Mint else Muted)},label={Text(label)},enabled=enabled,colors=FilterChipDefaults.filterChipColors(selectedContainerColor=Color(0xFF263C3C),selectedLabelColor=Mint))}
    }
    Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal=18.dp,vertical=10.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
     val c=p.clips.getOrNull(selected.coerceIn(0,(p.clips.size-1).coerceAtLeast(0)))
     if(c==null)Text("＋ 영상으로 클립을 추가하세요.",color=Muted)
     else{
      Text("클립 ${selected+1} · ${c.name}",fontSize=12.sp,color=Muted,maxLines=1,overflow=TextOverflow.Ellipsis)
      when(tool){
       "컷 편집"->{
        Text("장면 둘러보기",color=Color.White,fontWeight=FontWeight.SemiBold)
        Text("스틸컷을 누르면 해당 위치로 이동합니다. 아래 버튼으로 프레임 단위로 맞추세요.",color=Muted,fontSize=11.sp)
        StudioFrames(c,10,c.sourceTime(position-p.clipStart(selected)),{t->player?.pause();seek(p.clipStart(selected)+c.timelineTime(t))},Modifier.fillMaxWidth(),enabled=enabled)
        StudioActions{
         OutlinedButton(onClick={player?.pause();seek(p.clipStart(selected))},enabled=enabled){Text("시작")}
         OutlinedButton(onClick={player?.pause();seek(p.clipStart(selected)+c.timelineTime((c.sourceTime(position-p.clipStart(selected))-(1000/c.sourceFps.coerceAtLeast(1f)).roundToLong()).coerceAtLeast(c.startMs)))},enabled=enabled){Text("‹ 1프레임")}
         OutlinedButton(onClick={player?.pause();seek(p.clipStart(selected)+c.timelineTime((c.sourceTime(position-p.clipStart(selected))+(1000/c.sourceFps.coerceAtLeast(1f)).roundToLong()).coerceAtMost(c.endMs-1)))},enabled=enabled){Text("1프레임 ›")}
        }
        StudioActions{
         TextButton(onClick={val t=c.sourceTime(position-p.clipStart(selected));if(c.endMs-t>=100)change(c.copy(startMs=t))},enabled=enabled){Text("여기부터 시작",color=Mint)}
         TextButton(onClick={val t=c.sourceTime(position-p.clipStart(selected));if(t-c.startMs>=100)change(c.copy(endMs=t))},enabled=enabled){Text("여기서 끝",color=Mint)}
        }
        Text("남길 구간 · ${formatDetailedTime(c.startMs)} — ${formatDetailedTime(c.endMs)}",color=Color.White,fontSize=13.sp)
        RangeSlider(value=c.startMs.toFloat()..c.endMs.toFloat(),onValueChange={r->val start=r.start.roundToLong().coerceIn(0,c.durationMs-100);val end=r.endInclusive.roundToLong().coerceIn(start+100,c.durationMs);change(c.copy(startMs=start,endMs=end),true)},valueRange=0f..c.durationMs.toFloat(),enabled=enabled)
        StudioActions{
         OutlinedButton(onClick={val parts=c.splitAt(position-p.clipStart(selected));if(parts==null)status="클립 안쪽으로 재생선을 옮겨 주세요. 양쪽에 최소 0.1초가 필요합니다." else{update(p.copy(clips=p.clips.take(selected)+listOf(parts.first,parts.second)+p.clips.drop(selected+1)));selected+=1}},enabled=enabled && p.clips.size<30){Text("✂ 재생선에서 분할")}
         OutlinedButton(onClick={update(p.copy(clips=p.clips.toMutableList().apply{add(selected+1,c.copy(id=UUID.randomUUID().toString()))}))},enabled=enabled && p.clips.size<30){Text("복제")}
        }
        StudioActions{
         OutlinedButton(onClick={val list=p.clips.toMutableList();java.util.Collections.swap(list,selected,selected-1);update(p.copy(clips=list));selected-=1},enabled=enabled && selected>0){Text("← 앞")}
         OutlinedButton(onClick={val list=p.clips.toMutableList();java.util.Collections.swap(list,selected,selected+1);update(p.copy(clips=list));selected+=1},enabled=enabled && selected<p.clips.lastIndex){Text("뒤 →")}
         TextButton(onClick={update(p.copy(clips=p.clips.filterNot{it.id==c.id}))},enabled=enabled){Text("삭제",color=Color(0xFFFFB5B9))}
        }
        Text("재생선을 원하는 위치에 놓고 분할한 뒤 필요 없는 클립을 삭제하세요. ↶ 버튼으로 되돌릴 수 있습니다.",color=Muted,fontSize=12.sp)
       }
       "속도"->{
        StudioActions{listOf(.25f,.5f,1f,1.5f,2f,4f).forEach{v->FilterChip(selected=c.speed==v,onClick={change(c.copy(speed=v))},label={Text("${v}×")},enabled=enabled)}}
        Text("영상과 소리 속도를 함께 변경합니다. 음정 유지 설정을 적용합니다.",color=Muted,fontSize=12.sp)
       }
       "크롭"->{
        Row(verticalAlignment=Alignment.CenterVertically){Text("프로젝트 화면비 · ${p.aspect}",Modifier.weight(1f),color=Color.White);TextButton(onClick={showRatio=true},enabled=enabled){Text("직접 입력",color=Mint)}}
        StudioActions{listOf("원본","9:16","16:9","1:1","4:5","3:4","2:3","21:9").forEach{a->FilterChip(selected=p.aspect==a,onClick={update(p.copy(aspect=a))},label={Text(a)},enabled=enabled)}}
        Row(verticalAlignment=Alignment.CenterVertically){Text("화면 채우기 (가장자리 자르기)",Modifier.weight(1f),color=Muted,fontSize=13.sp);Switch(checked=p.fillCanvas,onCheckedChange={update(p.copy(fillCanvas=it))},enabled=enabled)}
        StudioActions{OutlinedButton(onClick={change(c.copy(rotation=(c.rotation+90)%360))},enabled=enabled){Text("↻ 90° 회전")};FilterChip(selected=c.mirror,onClick={change(c.copy(mirror=!c.mirror))},label={Text("좌우 반전")},enabled=enabled)}
        Row(verticalAlignment=Alignment.CenterVertically){Text("이 클립 크롭",Modifier.weight(1f),color=Color.White);Switch(c.cropEnabled,{change(c.copy(cropEnabled=it))},enabled=enabled)}
        StudioSlider("크롭 확대 · ${"%.2f".format(c.cropZoom)}×",c.cropZoom,1f..4f,enabled){change(c.copy(cropEnabled=true,cropZoom=it),true)}
        Row(verticalAlignment=Alignment.CenterVertically){Text("미리보기 드래그 · 핀치 조작",Modifier.weight(1f),color=Muted,fontSize=12.sp);Switch(gestures,{gestures=it},enabled=enabled)}
        Text("원본 미리보기에서 중심을 터치하세요. 크롭 이동·확대와 자동 추적은 MP4와 WebP 모두에 적용됩니다.",color=Muted,fontSize=12.sp)
        TextButton(onClick={change(c.copy(cropEnabled=false,cropZoom=1f,focusX=.5f,focusY=.5f,targetSelected=false,autoTrack=emptyList(),manualTrack=emptyList()))},enabled=enabled){Text("크롭 · 추적 초기화")}
       }
       "추적"->{
        Text("① 중심 선택  →  ② 영역 확인  →  ③ 추적",color=Color.White,fontWeight=FontWeight.SemiBold)
        Text(if(c.targetSelected)"대상 선택됨 · 파란 상자가 한 대상만 감싸도록 조절하세요." else "원본 미리보기에서 추적할 대상의 중심을 터치하세요.",color=if(c.targetSelected)Mint else Muted,fontSize=12.sp)
        StudioSlider("대상 인식 영역 · ${(c.targetSize*100).roundToInt()}%",c.targetSize,.08f..65f/100,enabled){change(c.copy(targetSize=it),true)}
        StudioActions{listOf("SUBJECT" to "AI 대상","FACE" to "얼굴","UPPER_BODY" to "상반신","FULL_BODY" to "전신").forEach{(mode,label)->FilterChip(selected=c.trackingMode==mode,onClick={change(c.copy(trackingMode=mode))},label={Text(label)},enabled=enabled)}}
        StudioSlider("추적 크롭 확대 · ${"%.2f".format(c.cropZoom)}×",c.cropZoom,1f..4f,enabled){change(c.copy(cropEnabled=true,cropZoom=it),true)}
        StudioActions{
         Button(onClick={
          player?.pause();rawFraming=true;analyzing=true;progress=0f
          val start=c.sourceTime(position-p.clipStart(selected)).coerceAtMost(c.endMs-100)
          if(c.trackingMode=="SUBJECT")deepTracker.analyze(c,start,{status=it},{progress=it},{tracked->
           change(c.copy(cropEnabled=true,autoTrack=(c.autoTrack.filter{it.timeMs<start}+tracked.points).sortedBy{it.timeMs}));analyzing=false
           status=tracked.lostAtMs?.let{"${formatDetailedTime(it)}에서 대상 신뢰도가 낮아져 위치를 유지했습니다. 해당 시점으로 이동해 대상을 다시 지정하세요."} ?: "AI 추적 완료 · 결과 미리보기에서 확인하세요."
           tracked.lostAtMs?.let{seek(p.clipStart(selected)+c.timelineTime(it))}
          },{error=it;analyzing=false})
          else tracker.analyze(Uri.parse(c.uri),start,c.endMs,c.focusX,c.focusY,runCatching{TrackingMode.valueOf(c.trackingMode)}.getOrDefault(TrackingMode.SUBJECT),
           {status=it},{progress=it},{points->change(c.copy(cropEnabled=true,autoTrack=(c.autoTrack.filter{it.timeMs<start}+points).sortedBy{it.timeMs}));analyzing=false;status="추적 완료 · ${points.size}개 지점. 결과 미리보기에서 확인하세요."},{error=it;analyzing=false},{analyzing=false})
         },enabled=enabled && c.targetSelected && c.endMs-sourceMs>=100,colors=ButtonDefaults.buttonColors(containerColor=Mint,contentColor=Color(0xFF08271F))){Text("현재부터 자동 추적")}
         OutlinedButton(onClick={player?.pause();seek(p.clipStart(selected));rawFraming=true},enabled=enabled){Text("첫 프레임")}
        }
        StudioActions{
         OutlinedButton(onClick={val time=c.sourceTime(position-p.clipStart(selected));change(c.copy(cropEnabled=true,manualTrack=(c.manualTrack.filterNot{kotlin.math.abs(it.timeMs-time)<80}+FocusKeyframe(time,c.focusX,c.focusY)).sortedBy{it.timeMs}));status="현재 위치에 수동 보정점을 저장했습니다."},enabled=enabled){Text("＋ 수동 보정점")}
         TextButton(onClick={change(c.copy(manualTrack=c.manualTrack.filterNot{kotlin.math.abs(it.timeMs-sourceMs)<250}))},enabled=enabled){Text("근처 보정점 제거")}
        }
        Text("자동 ${c.autoTrack.size}개 · 수동 ${c.manualTrack.size}개",color=Mint,fontSize=12.sp)
        if(c.manualTrack.isNotEmpty())StudioActions{c.manualTrack.filter{it.timeMs in c.startMs..c.endMs}.forEach{k->AssistChip(onClick={seek(p.clipStart(selected)+c.timelineTime(k.timeMs));rawFraming=true},label={Text(formatDetailedTime(k.timeMs))},enabled=enabled)}}
        Text("동물·사물은 ‘AI 대상’을 선택하세요. 선택 영역에 다른 대상이 들어오지 않게 맞추세요. 추적 후 다른 시점에서 대상을 터치하면 수동 보정점이 추가됩니다. 추적은 현재 위치부터 클립 끝까지 진행합니다.",color=Muted,fontSize=12.sp)
        TextButton(onClick={change(c.copy(autoTrack=emptyList(),manualTrack=emptyList()));status="추적 경로를 지웠습니다."},enabled=enabled){Text("추적 경로 지우기")}
       }
       "색 보정"->{
        Text("0이 원본입니다. 세 조절값을 모두 -100~+100 기준으로 표시합니다.",color=Muted,fontSize=12.sp)
        StudioActions{listOf("원본","선명","밝은","부드럽게","흑백").forEach{preset->OutlinedButton(onClick={change(when(preset){"선명"->c.copy(brightness=.02f,contrast=.10f,saturation=18f);"밝은"->c.copy(brightness=.08f,contrast=.02f,saturation=6f);"부드럽게"->c.copy(brightness=.03f,contrast=-.08f,saturation=-8f);"흑백"->c.copy(brightness=0f,contrast=.04f,saturation=-100f);else->c.copy(brightness=0f,contrast=0f,saturation=0f)})},enabled=enabled){Text(preset)}}}
        StudioColorSlider("밝기",c.brightness*200f,enabled){change(c.copy(brightness=(it/200f).coerceIn(-.5f,.5f)),true)}
        StudioColorSlider("대비",c.contrast*200f,enabled){change(c.copy(contrast=(it/200f).coerceIn(-.5f,.5f)),true)}
        StudioColorSlider("채도",c.saturation,enabled){change(c.copy(saturation=it.coerceIn(-100f,100f)),true)}
        TextButton(onClick={change(c.copy(brightness=0f,contrast=0f,saturation=0f))},enabled=enabled){Text("색 보정 전체 초기화")}
       }
       "글자"->{
        OutlinedTextField(value=c.caption,onValueChange={change(c.copy(caption=it.take(180)),true)},label={Text("이 클립에 표시할 글자")},supportingText={Text("클립 전체에 표시 · 최대 180자 / 4줄")},minLines=2,maxLines=4,enabled=enabled,modifier=Modifier.fillMaxWidth())
        StudioActions{listOf("위" to .7f,"중앙" to 0f,"아래" to -.7f).forEach{(name,y)->FilterChip(selected=kotlin.math.abs(c.captionY-y)<.1,onClick={change(c.copy(captionY=y))},label={Text(name)},enabled=enabled)}}
        StudioSlider("글자 크기",c.captionSize,.7f..1.4f,enabled){change(c.copy(captionSize=it),true)}
        StudioActions{listOf("WHITE" to "흰색","YELLOW" to "노랑","MINT" to "민트","BLACK" to "검정").forEach{(key,label)->FilterChip(selected=c.captionColor==key,onClick={change(c.copy(captionColor=key))},label={Text(label)},enabled=enabled)}}
        Row(verticalAlignment=Alignment.CenterVertically){Text("글자 배경",Modifier.weight(1f),color=Muted);Switch(checked=c.captionBackground,onCheckedChange={change(c.copy(captionBackground=it))},enabled=enabled)}
       }
       "오디오"->{
        StudioSlider("선택한 클립 원음 ${(c.volume*100).roundToInt()}%",c.volume,0f..1f,enabled){change(c.copy(volume=it),true)}
        StudioActions{OutlinedButton(onClick={change(c.copy(volume=if(c.volume>0)0f else 1f))},enabled=enabled){Text(if(c.volume==0f)"원음 켜기" else "음소거")};OutlinedButton(onClick={musicPicker.launch(arrayOf("audio/*"))},enabled=enabled){Text("♫ 음악 선택")}}
        p.music?.let{m->
         Text(m.name,color=Muted,maxLines=1,overflow=TextOverflow.Ellipsis)
         StudioSlider("배경음악 ${(m.volume*100).roundToInt()}%",m.volume,0f..1f,enabled){update(p.copy(music=m.copy(volume=it)),true)}
         val maxStart=p.durationMs.coerceAtLeast(1).toFloat()
         StudioSlider("타임라인 시작 · ${formatDetailedTime(m.startMs)}",m.startMs.toFloat(),0f..maxStart,enabled){update(p.copy(music=m.copy(startMs=it.roundToLong())),true)}
         if(m.durationMs>200){
          StudioSlider("음악 IN · ${formatDetailedTime(m.trimStartMs)}",m.trimStartMs.toFloat(),0f..(m.trimEndMs-100).coerceAtLeast(1).toFloat(),enabled){update(p.copy(music=m.copy(trimStartMs=it.roundToLong().coerceAtMost(m.trimEndMs-100))),true)}
          StudioSlider("음악 OUT · ${formatDetailedTime(m.trimEndMs)}",m.trimEndMs.toFloat(),(m.trimStartMs+100).coerceAtMost(m.durationMs).toFloat()..m.durationMs.toFloat(),enabled){update(p.copy(music=m.copy(trimEndMs=it.roundToLong().coerceAtLeast(m.trimStartMs+100))),true)}
         }
         Row(verticalAlignment=Alignment.CenterVertically){Text("음악 반복",Modifier.weight(1f),color=Muted);Switch(checked=m.loop,onCheckedChange={update(p.copy(music=m.copy(loop=it)))},enabled=enabled)}
         TextButton(onClick={update(p.copy(music=null))},enabled=enabled){Text("배경음악 제거")}
        }
        Row(verticalAlignment=Alignment.CenterVertically){Text("시작·끝 오디오 페이드",Modifier.weight(1f),color=Muted);Switch(checked=p.audioFade,onCheckedChange={update(p.copy(audioFade=it))},enabled=enabled)}
        Text("원음과 음악 음량을 각각 조절하고, 음악 시작 위치·IN/OUT·반복을 지정할 수 있습니다.",color=Muted,fontSize=12.sp)
       }
      }
     }
     if(status.isNotBlank())Text(status,color=Mint,fontSize=12.sp)
    }
   }
   if(loading || busy || analyzing){
    LinearProgressIndicator(progress={if(loading).15f else progress},modifier=Modifier.fillMaxWidth(),color=Mint)
    Row(Modifier.padding(horizontal=18.dp,vertical=6.dp),verticalAlignment=Alignment.CenterVertically){Text(if(loading)"파일을 불러오는 중…" else status,Modifier.weight(1f),color=Muted,fontSize=12.sp);if(busy || analyzing)TextButton(onClick={exporter.cancel();exportRequest=null;tracker.cancel();deepTracker.cancel();busy=false;analyzing=false;status="작업을 취소했습니다."}){Text("취소")}}
   }
  }
 }
 if(error!=null)AlertDialog(onDismissRequest={error=null},title={Text("확인이 필요해요")},text={Text(error!!)},confirmButton={TextButton(onClick={error=null}){Text("확인")}})
 val p=project
 if(showRatio && p!=null){
  var rw by remember{mutableStateOf("4")};var rh by remember{mutableStateOf("5")}
  val ratio=(rw.toFloatOrNull() ?: 0f)/(rh.toFloatOrNull() ?: 0f)
  AlertDialog(onDismissRequest={showRatio=false},title={Text("크롭 비율 직접 입력")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(rw,{rw=it.filter(Char::isDigit).take(4)},Modifier.weight(1f),label={Text("가로")},singleLine=true);OutlinedTextField(rh,{rh=it.filter(Char::isDigit).take(4)},Modifier.weight(1f),label={Text("세로")},singleLine=true)};Text("예: 4 : 5, 1920 : 1080 · 가로/세로 비율 0.1~10")}},confirmButton={TextButton(onClick={update(p.copy(aspect="$rw:$rh"));showRatio=false},enabled=ratio.isFinite() && ratio in .1f..10f){Text("적용")}},dismissButton={TextButton(onClick={showRatio=false}){Text("취소")}})
 }
 if(showRename && p!=null){var name by remember{mutableStateOf(p.name)};AlertDialog(onDismissRequest={showRename=false},title={Text("프로젝트 이름")},text={OutlinedTextField(value=name,onValueChange={name=it.take(50)},singleLine=true)},confirmButton={TextButton(onClick={update(p.copy(name=name.ifBlank{"새 프로젝트"}));showRename=false}){Text("저장")}},dismissButton={TextButton(onClick={showRename=false}){Text("취소")}})}
 deleteRequest?.let{target->
  AlertDialog(onDismissRequest={deleteRequest=null},title={Text("프로젝트 삭제")},text={Text("‘${target.name}’ 프로젝트를 삭제할까요? 편집 정보는 복구할 수 없습니다. 원본 영상 파일은 삭제하지 않습니다.")},confirmButton={TextButton(onClick={scope.launch{val ok=withContext(Dispatchers.IO){StudioProjectStore.delete(context,target)};if(ok){projects=withContext(Dispatchers.IO){StudioProjectStore.list(context)};deleteRequest=null}else error="프로젝트를 삭제하지 못했습니다."}}){Text("삭제",color=Color(0xFFFFB5B9))}},dismissButton={TextButton(onClick={deleteRequest=null}){Text("취소")}})
 }
 if(showExport && p!=null)StudioExportSheet(p,{update(it)},{showExport=false},{showExport=false;player?.pause();busy=true;result=null;progress=0f;exportRequest=project})
 result?.let{files->StudioResultsSheet(files,{result=null},{error=it})}

}
@Composable private fun StudioActions(content:@Composable RowScope.()->Unit){Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically,content=content)}
@Composable private fun StudioSlider(label:String,value:Float,range:ClosedFloatingPointRange<Float>,enabled:Boolean,onValue:(Float)->Unit){Column{Text(label,color=Muted,fontSize=13.sp);Slider(value=value.coerceIn(range.start,range.endInclusive),onValueChange=onValue,valueRange=range,enabled=enabled)}}
@Composable private fun StudioColorSlider(label:String,value:Float,enabled:Boolean,onValue:(Float)->Unit){val v=value.coerceIn(-100f,100f);Column{Row(Modifier.fillMaxWidth()){Text(label,color=Muted,fontSize=13.sp,modifier=Modifier.weight(1f));Text((if(v>0)"+" else "")+v.roundToInt(),color=if(kotlin.math.abs(v)<.5f) Muted else Mint,fontSize=13.sp)};Slider(value=v,onValueChange=onValue,valueRange=-100f..100f,steps=199,enabled=enabled)}}
@Composable private fun StudioThumbnail(clip:StudioClip,modifier:Modifier){
 val context=LocalContext.current
 val bitmap by produceState<Bitmap?>(null,clip.uri,clip.startMs){delay(150);value=withContext(Dispatchers.IO){thumbnailMutex.withLock{val r=MediaMetadataRetriever();try{r.setDataSource(context,Uri.parse(clip.uri));r.getScaledFrameAtTime(clip.startMs*1000,MediaMetadataRetriever.OPTION_CLOSEST_SYNC,120,80)}catch(e:Exception){null}finally{runCatching{r.release()}}}}}
 Box(modifier.background(Color(0xFF303946)),contentAlignment=Alignment.Center){bitmap?.let{Image(it.asImageBitmap(),contentDescription=clip.name,contentScale=ContentScale.Crop,modifier=Modifier.fillMaxSize())} ?: Text("▶",color=Muted)}
}
@Composable private fun StudioPreview(project:StudioProject,busy:Boolean,requestedMs:Long,onPlayer:(CompositionPlayer?)->Unit,onPosition:(Long)->Unit,onPlaying:(Boolean)->Unit,onError:(String)->Unit){
 val context=LocalContext.current;val latestRequested by rememberUpdatedState(requestedMs);val latestPosition by rememberUpdatedState(onPosition);val latestPlaying by rememberUpdatedState(onPlaying);val latestError by rememberUpdatedState(onError)
 val keyboard=WindowInsets.ime.getBottom(LocalDensity.current)>0;val height=if(keyboard)84.dp else(LocalConfiguration.current.screenHeightDp*.28f).coerceIn(145f,290f).dp
 var player by remember{mutableStateOf<CompositionPlayer?>(null)}
 var viewerZoom by remember{mutableFloatStateOf(1f)}
 var viewerOffsetX by remember{mutableFloatStateOf(0f)};var viewerOffsetY by remember{mutableFloatStateOf(0f)}
 DisposableEffect(busy){
  val created=if(busy)null else runCatching<CompositionPlayer?>{CompositionPlayer.Builder(context).build()}.getOrElse{latestError("미리보기 준비 실패: ${it.message}");null}
  player=created;onPlayer(created)
  val listener=object:Player.Listener{override fun onPlayerError(error:PlaybackException){latestError("미리보기 오류: ${error.message}\n클립을 다시 선택하거나 해상도를 낮춰 주세요.")};override fun onIsPlayingChanged(isPlaying:Boolean){latestPlaying(isPlaying)}}
  created?.addListener(listener);onDispose{onPlayer(null);latestPlaying(false);created?.removeListener(listener);created?.release()}
 }
 LaunchedEffect(project,player,busy){val active=player ?: return@LaunchedEffect;active.pause();if(busy || project.clips.isEmpty()){active.stop();return@LaunchedEffect};delay(450);try{val position=latestRequested.coerceIn(0,(project.durationMs-1).coerceAtLeast(0));active.setComposition(StudioMedia.composition(project),position);active.prepare()}catch(e:Exception){latestError("미리보기 구성 실패: ${e.message}")}}
 LaunchedEffect(player){while(true){player?.let{if(it.playbackState!=Player.STATE_IDLE)latestPosition(it.currentPosition.coerceAtLeast(0))};delay(100)}}
 Box(Modifier.fillMaxWidth().height(height).background(Color.Black),contentAlignment=Alignment.Center){
  AndroidView(factory={PlayerView(it).apply{useController=false;resizeMode=AspectRatioFrameLayout.RESIZE_MODE_FIT;keepScreenOn=false}},update={it.player=player},onRelease={it.player=null},modifier=Modifier.fillMaxSize().pointerInput(Unit){detectTransformGestures{_,pan,zoom,_->viewerZoom=(viewerZoom*zoom).coerceIn(1f,4f);if(viewerZoom<=1.01f){viewerOffsetX=0f;viewerOffsetY=0f}else{viewerOffsetX+=pan.x;viewerOffsetY+=pan.y}}}.graphicsLayer{scaleX=viewerZoom;scaleY=viewerZoom;translationX=viewerOffsetX;translationY=viewerOffsetY})
  Row(Modifier.align(Alignment.TopEnd).padding(6.dp),horizontalArrangement=Arrangement.spacedBy(2.dp)){listOf(1f,1.5f,2f).forEach{z->FilterChip(selected=viewerZoom==z,onClick={viewerZoom=z;if(z==1f){viewerOffsetX=0f;viewerOffsetY=0f}},label={Text("${z}×",fontSize=10.sp)})}}
  if(project.clips.isEmpty())Text("영상 클립을 추가하세요",color=Muted)
  if(busy)Surface(color=Color(0xBB11151D),shape=RoundedCornerShape(12.dp)){Text("내보내는 동안 미리보기를 멈춥니다",Modifier.padding(14.dp),color=Color.White,fontSize=12.sp)}
 }
}
