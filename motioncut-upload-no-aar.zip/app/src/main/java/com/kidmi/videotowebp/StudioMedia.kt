package com.kidmi.videotowebp
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import androidx.media3.common.C
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.SpeedParameters
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.DefaultGainProvider
import androidx.media3.common.audio.GainProcessor
import androidx.media3.common.audio.SpeedProvider
import androidx.media3.effect.*
import androidx.media3.transformer.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
object StudioMedia {
 fun composition(p:StudioProject):Composition {
  p.validate();val(w,h)=p.outputSize()
  val items=p.clips.mapIndexed{index,c->
   val media=MediaItem.Builder().setUri(c.uri).setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.startMs).setEndPositionMs(c.endMs).build()).build()
   val effects=mutableListOf<Effect>()
   if(c.cropEnabled)effects+=StudioCropEffect(c,p.aspect,p.clipStart(index))
   if(c.rotation!=0 || c.mirror)effects+=ScaleAndRotateTransformation.Builder().setRotationDegrees(c.rotation.toFloat()).setScale(if(c.mirror)-1f else 1f,1f).build()
   effects+=Presentation.createForWidthAndHeight(w,h,if(p.fillCanvas)Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP else Presentation.LAYOUT_SCALE_TO_FIT)
   if(c.brightness!=0f)effects+=Brightness(c.brightness)
   if(c.contrast!=0f)effects+=Contrast(c.contrast)
   if(c.saturation!=0f)effects+=HslAdjustment.Builder().adjustSaturation(c.saturation).build()
   if(c.caption.isNotBlank())effects+=OverlayEffect(listOf(BitmapOverlay.createStaticBitmapOverlay(caption(c.caption,w,c.captionSize,c.captionColor,c.captionBackground),StaticOverlaySettings.Builder().setBackgroundFrameAnchor(0f,c.captionY.coerceIn(-.75f,.75f)).build())))
   val audio=if(c.volume<1f)listOf(gain(c.volume)) else emptyList()
   EditedMediaItem.Builder(media).setDurationUs(c.durationMs*1000).setFrameRate(p.fps).setEffects(Effects(audio,effects)).setSpeed(SpeedParameters(object:SpeedProvider{
    override fun getSpeed(timeUs:Long)=c.speed
    override fun getNextSpeedChangeTimeUs(timeUs:Long)=C.TIME_UNSET
   },true)).build()
  }
  val sequences=mutableListOf(EditedMediaItemSequence.Builder(setOf(C.TRACK_TYPE_VIDEO,C.TRACK_TYPE_AUDIO)).addItems(items).build())
  p.music?.let{m->
   val media=MediaItem.Builder().setUri(m.uri).setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setStartPositionMs(m.trimStartMs).setEndPositionMs(m.trimEndMs).build()).build()
   val item=EditedMediaItem.Builder(media).setDurationUs(m.durationMs*1000).setRemoveVideo(true).setEffects(Effects(listOf(gain(m.volume)),emptyList())).build()
   val builder=EditedMediaItemSequence.Builder(setOf(C.TRACK_TYPE_AUDIO))
   if(m.startMs>0)builder.addGap(m.startMs*1000)
   builder.addItem(item).setIsLooping(m.loop)
   sequences+=builder.build()}
  return Composition.Builder(sequences).setEffects(Effects(if(p.audioFade)listOf(gain(1f,p.durationMs)) else emptyList(),emptyList())).setHdrMode(Composition.HDR_MODE_TONE_MAP_HDR_TO_SDR_USING_OPEN_GL).build()
 }
 private fun gain(volume:Float,durationMs:Long=0):AudioProcessor{
  val provider=DefaultGainProvider.Builder(volume)
  if(durationMs>0){val fade=minOf(500_000L,durationMs*1000/3).coerceAtLeast(2);provider.addFadeAt(0,fade,DefaultGainProvider.FADE_IN_LINEAR);provider.addFadeAt(durationMs*1000-fade,fade,DefaultGainProvider.FADE_OUT_LINEAR)}
  return GainProcessor(provider.build())
 }
 private fun caption(text:String,videoWidth:Int,size:Float,colorName:String,background:Boolean):Bitmap{
  val w=(videoWidth*.90f).toInt().coerceAtLeast(120);val pad=(videoWidth*.025f).toInt().coerceAtLeast(6)
  val paint=TextPaint(Paint.ANTI_ALIAS_FLAG).apply{color=when(colorName){"YELLOW"->android.graphics.Color.rgb(255,224,92);"MINT"->android.graphics.Color.rgb(131,240,209);"BLACK"->android.graphics.Color.BLACK;else->android.graphics.Color.WHITE};textSize=videoWidth*.065f*size.coerceIn(.7f,1.4f);typeface=android.graphics.Typeface.create("sans-serif-medium",0)}
  val txt=text.take(180);val layout=StaticLayout.Builder.obtain(txt,0,txt.length,paint,w-2*pad).setAlignment(Layout.Alignment.ALIGN_CENTER).setMaxLines(4).setEllipsize(TextUtils.TruncateAt.END).setIncludePad(false).build()
  return Bitmap.createBitmap(w,layout.height+2*pad,Bitmap.Config.ARGB_8888).apply{val canvas=Canvas(this);if(background)canvas.drawRoundRect(0f,0f,w.toFloat(),height.toFloat(),pad.toFloat(),pad.toFloat(),Paint(Paint.ANTI_ALIAS_FLAG).apply{color=0xB8000000.toInt()});canvas.translate(pad.toFloat(),pad.toFloat());layout.draw(canvas)}
 }
}
data class StudioOutput(val uri:Uri,val name:String,val bytes:Long,val mime:String="video/mp4")

/** A single composition is rendered once, then encoded to the selected delivery format. */
class StudioExporter(private val context:Context){
 companion object{private val filesExecutor=Executors.newSingleThreadExecutor()}
 private val handler=Handler(Looper.getMainLooper())
 private val generation=AtomicInteger()
 private val webp=ConversionEngine(context)
 private val formatEncoder=StudioFormatEncoder(context)
 private var transformer:Transformer?=null
 private var temporary:File?=null
 private var poll:Runnable?=null
 fun cancel(){
  generation.incrementAndGet();poll?.let(handler::removeCallbacks);poll=null
  transformer?.cancel();transformer=null;webp.cancel();formatEncoder.cancel();temporary?.delete();temporary=null
 }
 fun export(project:StudioProject,onStatus:(String)->Unit,onProgress:(Float)->Unit,onComplete:(List<StudioOutput>)->Unit,onError:(String)->Unit){
  cancel();val token=generation.get()
  val free=android.os.StatFs(context.cacheDir.absolutePath).availableBytes
  val (ow,oh)=project.outputSize();val frames=(project.durationMs/1000.0*project.fps).coerceAtLeast(1.0)
  val workingEstimate=(ow.toDouble()*oh*frames*.035).toLong().coerceIn(96L*1024*1024,2L*1024*1024*1024)
  if(free<workingEstimate+128L*1024*1024){onError("내보내기 임시 공간이 부족합니다. 약 ${formatStudioBytes(workingEstimate+128L*1024*1024)} 이상의 여유 공간을 확보하거나 해상도/FPS를 낮춰 주세요.");return}
  val jobs=if(project.exportEachClip)project.clips.map{project.copy(clips=listOf(it),exportEachClip=false)} else listOf(project)
  val completed=mutableListOf<StudioOutput>()
  fun failed(message:String){if(generation.get()!=token)return;poll?.let(handler::removeCallbacks);transformer?.cancel();transformer=null;temporary?.delete();temporary=null;onError(message+(if(completed.isNotEmpty())"\n앞서 저장한 ${completed.size}개 파일은 출력 폴더에 남아 있습니다." else ""))}
  fun render(index:Int){
   if(generation.get()!=token)return
   if(index>=jobs.size){onProgress(1f);onComplete(completed.toList());return}
   val p=jobs[index];val jobStarted=android.os.SystemClock.elapsedRealtime();val output=File(context.cacheDir,"motioncut_${UUID.randomUUID()}.mp4");temporary=output
   val asWebP=p.outputFormat=="WebP"
   fun status(message:String){if(generation.get()==token)onStatus(if(jobs.size>1)"${index+1}/${jobs.size} · $message" else message)}
   fun progress(f:Float){if(generation.get()==token)onProgress((index+f)/jobs.size)}
   fun accept(files:List<StudioOutput>){if(generation.get()!=token)return;completed+=files;output.delete();temporary=null;render(index+1)}
   try{
    val composition=StudioMedia.composition(p)
    val engine=Transformer.Builder(context).setVideoMimeType(MimeTypes.VIDEO_H264).setAudioMimeType(MimeTypes.AUDIO_AAC)
     .setEncoderFactory(DefaultEncoderFactory.Builder(context).setEnableFallback(true).build())
     .addListener(object:Transformer.Listener{
      override fun onCompleted(composition:Composition,result:ExportResult){
       if(generation.get()!=token){output.delete();return};poll?.let(handler::removeCallbacks);poll=null;transformer=null
       if(asWebP){
        status("WebP 인코딩 중…")
        val settings=ConversionSettings(startMs=0,endMs=p.durationMs,fps=p.fps,quality=p.webpQuality,maxSide=p.maxSide,lossless=p.webpLossless,loopForever=p.loopForever,
         speed=runCatching{ConversionSpeed.valueOf(p.compression)}.getOrDefault(ConversionSpeed.FAST),outputTreeUri=p.outputFolder?.let(Uri::parse),
         splitMode=runCatching{SplitMode.valueOf(p.splitMode)}.getOrDefault(SplitMode.NONE),splitCount=p.splitCount,targetPartSizeMb=p.targetPartMb,targetTotalSizeMb=p.targetTotalMb.takeIf{it>0})
        webp.convert(Uri.fromFile(output),settings,::status,{progress(.65f+it*.35f)},
         {r->
          val source=p.clips.firstOrNull();if(source!=null){val base=estimateOutput(VideoInfo(source.name,p.durationMs,source.width,source.height,source.sourceFps),p.durationMs,p.fps,p.webpQuality,p.maxSide,p.webpLossless,p.clips.map{it.cropZoom}.average().toFloat().coerceIn(1f,4f),runCatching{ConversionSpeed.valueOf(p.compression)}.getOrDefault(ConversionSpeed.FAST)).seconds;StudioEtaCalibrator.record(context,base,(android.os.SystemClock.elapsedRealtime()-jobStarted)/1000.0)}
          accept(r.parts.map{StudioOutput(it.uri,it.fileName,it.sizeBytes,"image/webp")})},::failed,{if(generation.get()==token)failed("내보내기를 취소했습니다.")})
       }else{
        status("${p.outputFormat} 저장 중…")
        formatEncoder.encode(output,p.outputFormat,{encoded->
        filesExecutor.execute{
         var destination:Uri?=null
         try{
          require(encoded.length()>0){"내보낸 파일이 비어 있습니다."};if(generation.get()!=token){output.delete();return@execute}
          val extension=when(p.outputFormat){"MOV"->"mov";"MKV"->"mkv";"GIF"->"gif";else->"mp4"}
          val mime=when(p.outputFormat){"MOV"->"video/quicktime";"MKV"->"video/x-matroska";"GIF"->"image/gif";else->"video/mp4"}
          val name="MotionCut_${SimpleDateFormat("yyyyMMdd_HHmmss_SSS",Locale.US).format(Date())}.$extension"
          val folder=p.outputFolder?.let{androidx.documentfile.provider.DocumentFile.fromTreeUri(context,Uri.parse(it))}
          destination=if(folder!=null)requireNotNull(folder.createFile(mime,name)).uri else requireNotNull(context.contentResolver.insert((if(mime.startsWith("image/"))MediaStore.Images.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI),ContentValues().apply{
           put(MediaStore.Video.Media.DISPLAY_NAME,name);put(MediaStore.Video.Media.MIME_TYPE,mime);put(MediaStore.Video.Media.RELATIVE_PATH,(if(mime.startsWith("image/"))Environment.DIRECTORY_PICTURES else Environment.DIRECTORY_MOVIES)+"/MotionCut");put(MediaStore.Video.Media.IS_PENDING,1)
          }))
          val uri=destination
          context.contentResolver.openOutputStream(uri,"w").use{dest->requireNotNull(dest);encoded.inputStream().use{input->val buffer=ByteArray(65536);while(true){if(generation.get()!=token)throw java.util.concurrent.CancellationException();val n=input.read(buffer);if(n<0)break;dest.write(buffer,0,n)}}}
          if(generation.get()!=token)throw java.util.concurrent.CancellationException()
          if(folder==null)context.contentResolver.update(uri,ContentValues().apply{put(MediaStore.Video.Media.IS_PENDING,0)},null,null)
          val saved=StudioOutput(uri,name,encoded.length(),mime)
          handler.post{if(generation.get()==token)accept(listOf(saved)) else {filesExecutor.execute{runCatching{context.contentResolver.delete(uri,null,null)}}}}
         }catch(e:Exception){destination?.let{runCatching{context.contentResolver.delete(it,null,null)}};handler.post{failed("저장 실패: ${e.message}")}}finally{if(encoded!=output)encoded.delete();output.delete()}
        }
        },::failed)
       }
      }
      override fun onError(composition:Composition,result:ExportResult,exception:ExportException){failed("영상 처리 실패: ${exception.message ?: exception.errorCodeName}\n해상도를 낮추거나 문제가 있는 클립을 확인해 주세요.")}
     }).build()
    transformer=engine;status("편집 결과 렌더링 중…");progress(0f);engine.start(composition,output.absolutePath)
    val holder=ProgressHolder();poll=object:Runnable{override fun run(){if(generation.get()!=token || transformer==null)return;if(engine.getProgress(holder)==Transformer.PROGRESS_STATE_AVAILABLE)progress(holder.progress/100f*(if(asWebP).65f else .96f));handler.postDelayed(this,400)}}.also{handler.post(it)}
   }catch(e:Exception){failed("편집 준비 실패: ${e.message}")}
  }
  try{project.validate();require(project.outputFormat!="GIF" || (if(project.exportEachClip)project.clips.maxOf{it.outputDurationMs} else project.durationMs)<=60_000){"GIF는 파일 크기와 메모리를 위해 60초 이내로 잘라 내보내 주세요."};render(0)}catch(e:Exception){failed(e.message ?: "프로젝트를 확인해 주세요.")}
 }
}
