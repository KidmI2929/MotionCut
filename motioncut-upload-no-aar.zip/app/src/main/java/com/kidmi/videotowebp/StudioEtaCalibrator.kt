package com.kidmi.videotowebp
import android.content.Context
import kotlin.math.max

/** Learns a conservative per-device WebP ETA correction without storing media data. */
object StudioEtaCalibrator {
 private const val PREF="motioncut_eta_v1"; private const val KEY="webp_factor"
 fun factor(context:Context):Double=context.getSharedPreferences(PREF,0).getFloat(KEY,1f).toDouble().coerceIn(.35,4.0)
 fun adjustedSeconds(context:Context,base:Double)=max(.1,base*factor(context))
 fun record(context:Context,baseSeconds:Double,actualSeconds:Double){
  if(baseSeconds<=.05 || actualSeconds<=.05)return
  val prefs=context.getSharedPreferences(PREF,0);val old=factor(context);val sample=(actualSeconds/baseSeconds).coerceIn(.35,4.0)
  val next=(old*.7+sample*.3).coerceIn(.35,4.0)
  prefs.edit().putFloat(KEY,next.toFloat()).apply()
 }
}
