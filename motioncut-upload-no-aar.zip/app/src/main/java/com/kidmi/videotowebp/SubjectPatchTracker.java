package com.kidmi.videotowebp;

/** Bounded appearance tracking, with an immutable anchor to resist identity drift.
 * Ambiguous or low-texture matches return null: callers must hold, never pick another subject. */
public final class SubjectPatchTracker {
    private static final int N = 16, LENGTH = N * N * 3;
    private float[] anchor, recent;
    private float x, y, radius, initialRadius;
    private int frameWidth, frameHeight;
    private final float[] candidate = new float[LENGTH];
    private final float[] bestPatch = new float[LENGTH];

    public boolean initialize(int[] pixels, int width, int height, float nx, float ny) {
        frameWidth = width; frameHeight = height;
        x = Math.max(0, Math.min(width - 1, nx * width));
        y = Math.max(0, Math.min(height - 1, ny * height));
        radius = Math.max(8, Math.min(width, height) * 0.105f);
        initialRadius = radius;
        anchor = new float[LENGTH];
        if (!patch(pixels, x, y, radius, anchor) || variance(anchor) < 100) {
            anchor = null; return false;
        }
        recent = anchor.clone();
        return true;
    }

    public float[] update(int[] pixels, int width, int height) {
        if (anchor == null || width != frameWidth || height != frameHeight) return null;
        float range = Math.min(width, height) * 0.12f;
        int step = Math.max(2, Math.round(range / 12));
        float best = -2, bx = x, by = y, br = radius;
        // Keep scores to reject two spatially separate plausible matches.
        int searchRadius = ((int)range / step) * step;
        int side = 2 * (searchRadius / step) + 1;
        float[] scores = new float[side * side * 3];
        float[] xs = new float[scores.length], ys = new float[scores.length];
        int count = 0;
        for (float scale : new float[]{0.94f, 1f, 1.06f}) {
            float r = Math.max(initialRadius * .75f, Math.min(initialRadius * 1.35f, radius * scale));
            for (int dy = -searchRadius; dy <= searchRadius; dy += step) {
                for (int dx = -searchRadius; dx <= searchRadius; dx += step) {
                    float cx = x + dx, cy = y + dy;
                    if (!patch(pixels, cx, cy, r, candidate)) continue;
                    float a = similarity(anchor, candidate), b = similarity(recent, candidate);
                    if (a < .68f || b < .72f) continue;
                    float score = .65f * a + .35f * b;
                    scores[count] = score; xs[count] = cx; ys[count++] = cy;
                    if (score > best) {
                        best = score; bx = cx; by = cy; br = r;
                        System.arraycopy(candidate, 0, bestPatch, 0, LENGTH);
                    }
                }
            }
        }
        if (best < .76f) return null;
        for (int i = 0; i < count; i++) {
            if (Math.hypot(xs[i] - bx, ys[i] - by) > radius && best - scores[i] < .035f) return null;
        }
        x = bx; y = by; radius = br;
        if (best > .88f) {
            for (int i = 0; i < LENGTH; i++) recent[i] = .9f * recent[i] + .1f * bestPatch[i];
        }
        return new float[]{x / width, y / height};
    }

    private boolean patch(int[] pixels, float cx, float cy, float r, float[] out) {
        if (cx - r < 0 || cy - r < 0 || cx + r >= frameWidth || cy + r >= frameHeight) return false;
        int k = 0;
        for (int j = 0; j < N; j++) {
            int py = Math.round(cy - r + 2 * r * j / (N - 1));
            for (int i = 0; i < N; i++) {
                int px = Math.round(cx - r + 2 * r * i / (N - 1));
                int rgb = pixels[py * frameWidth + px];
                out[k++] = (rgb >> 16) & 255; out[k++] = (rgb >> 8) & 255; out[k++] = rgb & 255;
            }
        }
        return true;
    }
    private static float variance(float[] values) {
        double sum = 0, square = 0;
        for (float v : values) { sum += v; square += v * v; }
        return (float)(square / values.length - Math.pow(sum / values.length, 2));
    }
    private static float similarity(float[] a, float[] b) {
        double sa = 0, sb = 0, aa = 0, bb = 0, ab = 0;
        double color = 0;
        for (int c = 0; c < 3; c++) {
            double ca = 0, cb = 0;
            for (int i = c; i < LENGTH; i += 3) { ca += a[i]; cb += b[i]; }
            color += Math.abs(ca - cb) / (N * N * 255.0);
        }
        for (int i = 0; i < LENGTH; i++) {
            sa += a[i]; sb += b[i]; aa += a[i] * a[i]; bb += b[i] * b[i]; ab += a[i] * b[i];
        }
        double denom = Math.sqrt(Math.max(0, aa - sa * sa / LENGTH) * Math.max(0, bb - sb * sb / LENGTH));
        if (denom < 1) return -1;
        return (float)((ab - sa * sb / LENGTH) / denom - color * .35);
    }
}
