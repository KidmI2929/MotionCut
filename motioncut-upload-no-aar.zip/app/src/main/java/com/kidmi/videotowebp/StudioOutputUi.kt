package com.kidmi.videotowebp

import android.content.ClipData
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

@Composable internal fun StudioExportSheet(p:StudioProject,onUpdate:(StudioProject)->Unit,onDismiss:()->Unit,onExport:()->Unit){
 val context=LocalContext.current
 var folderError by remember{mutableStateOf<String?>(null)}
 val folderPicker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()){uri->if(uri!=null){
  runCatching{context.contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION);onUpdate(p.copy(outputFolder=uri.toString()))}.onFailure{folderError="이 폴더에 저장 권한을 얻지 못했습니다. 다른 폴더를 선택해 주세요."}
 }}
 Dialog(onDismissRequest=onDismiss,properties=DialogProperties(usePlatformDefaultWidth=false)){
  Surface(color=Color(0xFF111720),shape=RoundedCornerShape(24.dp),modifier=Modifier.fillMaxWidth(.94f).fillMaxHeight(.88f)){
   Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
    Text("EXPORT",color=StudioMint,fontSize=11.sp,fontWeight=FontWeight.Bold)
    Row(verticalAlignment=Alignment.CenterVertically){Text("마지막은, 원하는 포맷으로",Modifier.weight(1f),color=Color.White,fontSize=20.sp,fontWeight=FontWeight.Bold);TextButton(onClick=onDismiss){Text("닫기")}}
    Text("${p.clips.size}개 클립 · ${formatDuration(p.durationMs)} · 크롭/추적/효과 포함",color=StudioSubtle,fontSize=12.sp)
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(12.dp)){
     Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){
      listOf("MP4" to "영상 + 소리", "WebP" to "움직이는 이미지").forEach{(format,description)->
       Surface(color=if(p.outputFormat==format)Color(0xFF26433F) else StudioSurface,shape=RoundedCornerShape(14.dp),border=BorderStroke(1.dp,if(p.outputFormat==format)StudioMint else Color(0xFF303B4C)),modifier=Modifier.weight(1f).clickable{onUpdate(p.copy(outputFormat=format))}){
        Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){Text(format,fontSize=22.sp,fontWeight=FontWeight.Bold,color=if(p.outputFormat==format)StudioMint else Color.White);Text(description,fontSize=11.sp,color=StudioSubtle)}
       }
      }
     }
     OutputOptions{listOf("MOV","MKV","GIF").forEach{format->FilterChip(p.outputFormat==format,{onUpdate(p.copy(outputFormat=format))},{Text(format)})}}
     if(p.outputFormat=="GIF")Text("GIF는 소리 없이 반복 재생됩니다. 최대 60초까지 지원합니다.",color=StudioSubtle,fontSize=11.sp)
     if(p.outputFormat in listOf("MOV","MKV"))Text("H.264 영상과 AAC 오디오를 선택한 컨테이너로 저장합니다.",color=StudioSubtle,fontSize=11.sp)
     Text("해상도 · 긴 변",color=Color.White)
     OutputOptions{
      FilterChip(p.maxSide==null,{onUpdate(p.copy(maxSide=null))},{Text("원본")})
      listOf(320,480,720,1080).forEach{n->FilterChip(p.maxSide==n,{onUpdate(p.copy(maxSide=n))},{Text("${n}p")})}
     }
     Text("프레임 수",color=Color.White)
     OutputOptions{listOf(10,15,24,30).forEach{n->FilterChip(p.fps==n,{onUpdate(p.copy(fps=n))},{Text("$n fps")})}}
     Text("출력 크기 ${p.outputSize().first} × ${p.outputSize().second}",color=StudioSubtle,fontSize=12.sp)
     if(p.outputFormat=="WebP"){
      Text("WebP 품질 · ${p.webpQuality}",color=Color.White)
      Slider(p.webpQuality.toFloat(),{onUpdate(p.copy(webpQuality=it.toInt()))},valueRange=1f..100f,enabled=!p.webpLossless)
      OutputToggle("반복 재생",p.loopForever){onUpdate(p.copy(loopForever=it))}
      OutputToggle("WebP 단계 무손실 압축",p.webpLossless){onUpdate(p.copy(webpLossless=it))}
      Text("WebP에는 소리가 포함되지 않습니다. 무손실은 최종 WebP 인코딩 단계에 적용됩니다.",color=StudioSubtle,fontSize=11.sp)
      val source=p.clips.firstOrNull()
      if(source!=null){
       val estimate=estimateOutput(VideoInfo(source.name,p.durationMs,source.width,source.height,source.sourceFps),p.durationMs,p.fps,p.webpQuality,p.maxSide,p.webpLossless,p.clips.map{it.cropZoom}.average().toFloat().coerceIn(1f,4f),runCatching{ConversionSpeed.valueOf(p.compression)}.getOrDefault(ConversionSpeed.FAST))
       Surface(color=StudioSurface,shape=RoundedCornerShape(12.dp),modifier=Modifier.fillMaxWidth()){Row(Modifier.padding(12.dp)){Column(Modifier.weight(1f)){Text("예상 크기",color=StudioSubtle,fontSize=11.sp);Text(formatStudioBytes(estimate.sizeBytes),color=Color.White,fontWeight=FontWeight.Bold)};Column(horizontalAlignment=Alignment.End){Text("예상 변환 시간",color=StudioSubtle,fontSize=11.sp);Text("~%.1f초".format(java.util.Locale.US,StudioEtaCalibrator.adjustedSeconds(context,estimate.seconds)),color=Color.White,fontWeight=FontWeight.Bold)}}}
       Text("예상치는 이 기기에서 완료한 WebP 작업 속도로 자동 보정됩니다. 영상 내용에 따라 차이가 날 수 있습니다.",color=StudioSubtle,fontSize=10.sp)
      }
      Text("압축 속도",color=Color.White)
      OutputOptions{listOf("TURBO" to "빠르게","FAST" to "표준","BALANCED" to "균형","MAX_COMPRESSION" to "최대 압축").forEach{(key,label)->FilterChip(p.compression==key,{onUpdate(p.copy(compression=key))},{Text(label)})}}
      Text("파일 나누기",color=Color.White)
      OutputOptions{listOf("NONE" to "한 파일","COUNT" to "개수로","SIZE" to "용량으로").forEach{(key,label)->FilterChip(p.splitMode==key,{onUpdate(p.copy(splitMode=key))},{Text(label)})}}
      when(p.splitMode){
       "COUNT"->{Text("${p.splitCount}개로 분할",color=StudioSubtle);Slider(p.splitCount.toFloat(),{onUpdate(p.copy(splitCount=it.toInt()))},valueRange=2f..20f,steps=17)}
       "SIZE"->{Text("파일당 약 ${p.targetPartMb} MB",color=StudioSubtle);Slider(p.targetPartMb.toFloat(),{onUpdate(p.copy(targetPartMb=it.toInt()))},valueRange=1f..30f,steps=28)}
      }
      if(p.splitMode=="NONE"){
       OutputToggle("목표 용량에 맞추기",p.targetTotalMb>0){onUpdate(p.copy(targetTotalMb=if(it)8 else 0))}
       if(p.targetTotalMb>0){Text("목표 ${p.targetTotalMb} MB",color=StudioSubtle);Slider(p.targetTotalMb.toFloat(),{onUpdate(p.copy(targetTotalMb=it.toInt()))},valueRange=1f..30f,steps=28)}
      }
     }
     HorizontalDivider(color=Color(0xFF293344))
     OutputToggle("클립별로 각각 내보내기",p.exportEachClip){onUpdate(p.copy(exportEachClip=it))}
     Text(if(p.exportEachClip)"각 클립에 적용한 크롭·추적·효과를 유지해 개별 저장합니다." else "타임라인 순서대로 이어 붙인 하나의 편집 결과를 저장합니다.",color=StudioSubtle,fontSize=11.sp)
     Text("저장 위치",color=Color.White)
     Text(if(p.outputFolder==null)if(p.outputFormat !in listOf("WebP","GIF"))"갤러리 · Movies / MotionCut" else "갤러리 · Pictures / MotionCut" else "선택한 폴더",color=StudioSubtle,fontSize=12.sp)
     OutputOptions{OutlinedButton(onClick={folderPicker.launch(p.outputFolder?.let(Uri::parse))}){Text("폴더 선택")};if(p.outputFolder!=null)TextButton(onClick={onUpdate(p.copy(outputFolder=null))}){Text("갤러리로")}}
     folderError?.let{Text(it,color=Color(0xFFFFB5B9),fontSize=12.sp)}
    }
    Button(onClick=onExport,modifier=Modifier.fillMaxWidth().height(50.dp),shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(containerColor=StudioMint,contentColor=Color(0xFF08271F))){Text("${p.outputFormat}로 내보내기",fontWeight=FontWeight.Bold)}
   }
  }
 }
}
@Composable private fun OutputOptions(content:@Composable RowScope.()->Unit){Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp),content=content)}
@Composable private fun OutputToggle(label:String,value:Boolean,onChange:(Boolean)->Unit){Row(verticalAlignment=Alignment.CenterVertically){Text(label,Modifier.weight(1f),color=Color.White,fontSize=13.sp);Switch(value,onChange)}}
@Composable internal fun StudioResultsSheet(files:List<StudioOutput>,onDismiss:()->Unit,onError:(String)->Unit){
 val context=LocalContext.current
 fun share(selected:List<StudioOutput>){runCatching{
  val mime=selected.map{it.mime}.distinct().singleOrNull() ?: "*/*"
  val intent=if(selected.size==1)Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM,selected[0].uri) else Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM,ArrayList(selected.map{it.uri}))
  intent.type=mime;intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
  intent.clipData=ClipData.newRawUri("MotionCut",selected.first().uri).apply{selected.drop(1).forEach{addItem(ClipData.Item(it.uri))}}
  context.startActivity(Intent.createChooser(intent,"편집 결과 공유"))
 }.onFailure{onError("공유 앱을 열 수 없습니다.")}}
 AlertDialog(onDismissRequest=onDismiss,title={Text("편집 결과가 저장됐어요")},text={Column(Modifier.heightIn(max=400.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(12.dp)){
  Text("${files.size}개 파일 · ${"%.1f".format(files.sumOf{it.bytes}/1048576.0)} MiB")
  files.forEach{file->Surface(color=StudioSurface,shape=RoundedCornerShape(12.dp)){Column(Modifier.padding(12.dp)){
   Text(file.name,color=Color.White,fontSize=12.sp)
   Text("${file.mime.substringAfter('/').uppercase()} · ${"%.2f".format(file.bytes/1048576.0)} MiB",color=StudioSubtle,fontSize=11.sp)
   Row{TextButton(onClick={runCatching{context.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(file.uri,file.mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))}.onFailure{onError("이 포맷을 열 수 있는 앱을 찾지 못했습니다.")}}){Text("열기")};TextButton(onClick={share(listOf(file))}){Text("공유")}}
  }}}
 }},confirmButton={TextButton(onClick=onDismiss){Text("편집으로 돌아가기")}},dismissButton={TextButton(onClick={share(files)}){Text("모두 공유")}})
}

private fun formatStudioBytes(bytes:Long):String = if(bytes>=1048576) "%.1f MiB".format(java.util.Locale.US,bytes/1048576.0) else "%.0f KiB".format(java.util.Locale.US,bytes/1024.0)
