package com.kidmi.videotowebp
import android.content.Context
import android.os.Handler
import android.os.Looper
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File
import java.util.UUID
import java.util.concurrent.atomic.AtomicInteger

class StudioFormatEncoder(private val context:Context){
 private val generation=AtomicInteger();private val main=Handler(Looper.getMainLooper())
 private var session:Long?=null;private val files=mutableListOf<File>()
 fun cancel(){generation.incrementAndGet();session?.let{FFmpegKit.cancel(it)};session=null;synchronized(files){files.forEach{it.delete()};files.clear()}}
 fun encode(input:File,format:String,onComplete:(File)->Unit,onError:(String)->Unit){
  cancel();val token=generation.get()
  if(format=="MP4"){onComplete(input);return}
  val extension=when(format){"MOV"->"mov";"MKV"->"mkv";"GIF"->"gif";else->{onError("지원하지 않는 출력 포맷입니다.");return}}
  val output=File(context.cacheDir,"motioncut_${UUID.randomUUID()}.$extension");synchronized(files){files+=output}
  fun run(args:Array<String>,done:()->Unit){
   session=FFmpegKit.executeWithArgumentsAsync(arrayOf("-hide_banner","-loglevel","error","-nostdin","-y")+args){result->
    main.post{
     if(generation.get()==token){session=null;if(ReturnCode.isSuccess(result.returnCode))done() else onError("$format 변환 실패: ${result.failStackTrace ?: result.allLogsAsString.takeLast(800)}")}
    }
   }.sessionId
  }
  if(format=="GIF"){
   val palette=File(context.cacheDir,"palette_${UUID.randomUUID()}.png");synchronized(files){files+=palette}
   run(arrayOf("-i",input.absolutePath,"-vf","palettegen=max_colors=128:stats_mode=diff","-frames:v","1","-update","1",palette.absolutePath)){
    run(arrayOf("-i",input.absolutePath,"-i",palette.absolutePath,"-lavfi","paletteuse=dither=bayer:bayer_scale=3","-an","-loop","0",output.absolutePath)){palette.delete();onComplete(output)}
   }
  }else run(arrayOf("-i",input.absolutePath,"-map","0:v:0","-map","0:a?","-c","copy",output.absolutePath)){onComplete(output)}
 }
}
