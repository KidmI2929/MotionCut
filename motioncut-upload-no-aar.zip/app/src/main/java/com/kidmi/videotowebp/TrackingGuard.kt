package com.kidmi.videotowebp
import kotlin.math.hypot

/** Fail closed: a weak match never becomes the seed for a different subject. */
object TrackingGuard {
 fun accept(score:Float,oldX:Float,oldY:Float,newX:Float,newY:Float,oldArea:Float,newArea:Float,appearanceDistance:Float):Boolean {
  if(!listOf(score,oldX,oldY,newX,newY,oldArea,newArea,appearanceDistance).all{it.isFinite()})return false
  return score>=.55f && newX in 0f..1f && newY in 0f..1f && oldArea>0 && newArea>0 &&
   newArea/oldArea in .55f..1.8f && hypot(newX-oldX,newY-oldY)<=.16f && appearanceDistance<=.48f
 }
}
