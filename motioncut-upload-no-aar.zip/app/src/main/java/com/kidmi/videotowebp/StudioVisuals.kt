package com.kidmi.videotowebp

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext
import kotlin.math.abs

internal val StudioMint=Color(0xFF83F0D1)
internal val StudioSurface=Color(0xFF191F2A)
internal val StudioSubtle=Color(0xFF99A7BA)
private val studioDecodeMutex=Mutex()

@Composable internal fun StudioGlyph(kind:String,modifier:Modifier=Modifier.size(19.dp),color:Color=StudioMint){
 Canvas(modifier){
  val w=size.width;val h=size.height;val sw=1.7.dp.toPx()
  fun line(x:Float,y:Float,a:Float,b:Float)=drawLine(color,Offset(x*w,y*h),Offset(a*w,b*h),sw)
  when(kind){
   "컷 편집"->{drawCircle(color,w*.13f,Offset(w*.22f,h*.76f),style=Stroke(sw));drawCircle(color,w*.13f,Offset(w*.22f,h*.23f),style=Stroke(sw));line(.32f,.3f,.85f,.83f);line(.32f,.68f,.85f,.13f)}
   "크롭"->{line(.25f,.05f,.25f,.75f);line(.05f,.25f,.75f,.25f);line(.25f,.75f,.95f,.75f);line(.75f,.25f,.75f,.95f)}
   "추적"->{drawCircle(color,w*.35f,center,style=Stroke(sw));drawCircle(color,w*.11f,center,style=Stroke(sw));line(.5f,0f,.5f,.22f);line(.5f,.78f,.5f,1f);line(0f,.5f,.22f,.5f);line(.78f,.5f,1f,.5f)}
   "속도"->{drawArc(color,190f,160f,false,Offset(w*.08f,h*.14f),Size(w*.84f,h*.84f),style=Stroke(sw));line(.5f,.66f,.78f,.28f);line(.1f,.82f,.9f,.82f)}
   "색 보정"->{drawCircle(color,w*.35f,center,style=Stroke(sw));drawArc(color,-90f,180f,true,Offset(w*.15f,h*.15f),Size(w*.7f,h*.7f))}
   "글자"->{line(.15f,.18f,.85f,.18f);line(.5f,.18f,.5f,.85f);line(.35f,.85f,.65f,.85f)}
   "오디오"->{line(.36f,.2f,.36f,.75f);line(.36f,.2f,.82f,.12f);line(.82f,.12f,.82f,.65f);drawCircle(color,w*.12f,Offset(w*.24f,h*.78f));drawCircle(color,w*.12f,Offset(w*.70f,h*.68f))}
   else->{val p=Path().apply{moveTo(w*.25f,h*.12f);lineTo(w*.88f,h*.5f);lineTo(w*.25f,h*.88f);close()};drawPath(p,color)}
  }
 }
}

@Composable internal fun StudioFrames(clip:StudioClip,count:Int,currentSourceMs:Long,onSeek:(Long)->Unit,modifier:Modifier=Modifier,compact:Boolean=false,enabled:Boolean=true){
 val context=LocalContext.current
 val times=remember(clip.uri,clip.startMs,clip.endMs,count){List(count){i->clip.startMs+((clip.endMs-clip.startMs-1).coerceAtLeast(0)*i/(count-1).coerceAtLeast(1))}}
 var frames by remember(clip.uri,times){mutableStateOf<List<Pair<Long,Bitmap>>>(emptyList())}
 LaunchedEffect(clip.uri,times){delay(200);frames=withContext(Dispatchers.IO){studioDecodeMutex.withLock{
  val r=MediaMetadataRetriever()
  try{r.setDataSource(context,Uri.parse(clip.uri));times.mapNotNull{t->coroutineContext.ensureActive();runCatching{r.getScaledFrameAtTime(t*1000,MediaMetadataRetriever.OPTION_CLOSEST,160,100)}.getOrNull()?.let{t to it}}}catch(e:kotlinx.coroutines.CancellationException){throw e}catch(e:Exception){emptyList()}finally{runCatching{r.release()}}
 }}}
 val nearest=times.minByOrNull{abs(it-currentSourceMs)}
 @Composable fun tile(time:Long,index:Int,m:Modifier){
  val bitmap=frames.firstOrNull{it.first==time}?.second
  Box(m.background(Color(0xFF293447)).clickable(enabled=enabled){onSeek(time)},contentAlignment=Alignment.BottomStart){
   bitmap?.let{Image(it.asImageBitmap(),"${formatDetailedTime(time)} 스틸컷",Modifier.fillMaxSize(),contentScale=ContentScale.Crop)}
   if(!compact){if(time==nearest)Box(Modifier.matchParentSize().border(2.dp,StudioMint,RoundedCornerShape(4.dp)))
    Text(formatDetailedTime(time),color=Color.White,fontSize=10.sp,modifier=Modifier.background(Color(0xB0000000)).padding(horizontal=4.dp,vertical=2.dp))}
   else if(bitmap==null)Text("${index+1}",color=StudioSubtle,fontSize=10.sp,modifier=Modifier.padding(4.dp))
  }
 }
 if(compact)Row(modifier){times.forEachIndexed{i,t->tile(t,i,Modifier.weight(1f).fillMaxHeight())}}
 else LazyRow(modifier,horizontalArrangement=Arrangement.spacedBy(5.dp)){itemsIndexed(times){i,t->tile(t,i,Modifier.width(88.dp).height(64.dp))}}
}

@Composable internal fun StudioFramingPreview(c:StudioClip,aspect:String,sourceMs:Long,gestures:Boolean,height:androidx.compose.ui.unit.Dp,onFocus:(Float,Float)->Unit,onZoom:(Float)->Unit){
 val context=LocalContext.current
 var bitmap by remember(c.uri){mutableStateOf<Bitmap?>(null)}
 var failure by remember(c.uri,sourceMs){mutableStateOf(false)}
 val latestClip by rememberUpdatedState(c);val latestFocus by rememberUpdatedState(onFocus);val latestZoom by rememberUpdatedState(onZoom)
 LaunchedEffect(c.uri,sourceMs){delay(100);bitmap=withContext(Dispatchers.IO){studioDecodeMutex.withLock{
  val r=MediaMetadataRetriever();try{r.setDataSource(context,Uri.parse(c.uri));r.getScaledFrameAtTime(sourceMs*1000,MediaMetadataRetriever.OPTION_CLOSEST,720,720)}catch(e:Exception){null}finally{runCatching{r.release()}}
 }};failure=bitmap==null}
 val points=remember(c.autoTrack,c.manualTrack){c.trackingPoints()}
 BoxWithConstraints(Modifier.fillMaxWidth().height(height).background(Color(0xFF080C12)),contentAlignment=Alignment.Center){
  val ratio=c.width.toFloat()/c.height
  val displayWidth=if(maxWidth/maxHeight>ratio)maxHeight*ratio else maxWidth
  val displayHeight=displayWidth/ratio
  var interaction=Modifier.width(displayWidth).height(displayHeight)
  interaction=interaction.pointerInput(c.id){detectTapGestures{point->latestFocus((point.x/size.width).coerceIn(0f,1f),(point.y/size.height).coerceIn(0f,1f))}}
  if(gestures)interaction=interaction.pointerInput(c.id){detectTransformGestures{_,pan,zoom,_->
   val clip=latestClip
   if(abs(zoom-1f)>.002f)latestZoom((clip.cropZoom*zoom).coerceIn(1f,4f))
   else if(pan!=Offset.Zero)latestFocus((clip.focusX+pan.x/size.width).coerceIn(0f,1f),(clip.focusY+pan.y/size.height).coerceIn(0f,1f))
  }}
  Box(interaction){
   bitmap?.let{Image(it.asImageBitmap(),"원본 프레임 · 대상과 크롭 위치 지정",Modifier.fillMaxSize(),contentScale=ContentScale.FillBounds)}
   Canvas(Modifier.fillMaxSize()){
    val box=studioCropWindow(c.copy(cropEnabled=true),aspect,sourceMs,points)
    val x=box.left*size.width;val y=box.top*size.height;val w=box.width*size.width;val h=box.height*size.height
    val shade=Color.Black.copy(alpha=.52f)
    drawRect(shade,size=Size(size.width,y));drawRect(shade,Offset(0f,y+h),Size(size.width,(size.height-y-h).coerceAtLeast(0f)))
    drawRect(shade,Offset(0f,y),Size(x,h));drawRect(shade,Offset(x+w,y),Size((size.width-x-w).coerceAtLeast(0f),h))
    drawRect(StudioMint,Offset(x,y),Size(w,h),style=Stroke(2.dp.toPx()))
    for(i in 1..2){drawLine(Color.White.copy(alpha=.3f),Offset(x+w*i/3,y),Offset(x+w*i/3,y+h),1f);drawLine(Color.White.copy(alpha=.3f),Offset(x,y+h*i/3),Offset(x+w,y+h*i/3),1f)}
    if(points.size>1){val path=Path();points.forEachIndexed{i,p->if(i==0)path.moveTo(p.x*size.width,p.y*size.height) else path.lineTo(p.x*size.width,p.y*size.height)};drawPath(path,StudioMint.copy(alpha=.55f),style=Stroke(1.4.dp.toPx()))}
    if(c.targetSelected){
     val side=kotlin.math.min(size.width,size.height)*c.targetSize
     val left=(c.focusX*size.width-side/2).coerceIn(0f,size.width-side)
     val top=(c.focusY*size.height-side/2).coerceIn(0f,size.height-side)
     drawRect(Color(0xFF72ABFF),Offset(left,top),Size(side,side),style=Stroke(2.dp.toPx()))
    }
    val focus=studioFocus(points,sourceMs,c.focusX,c.focusY);drawCircle(StudioMint,5.dp.toPx(),Offset(focus.first*size.width,focus.second*size.height));drawCircle(Color.White,8.dp.toPx(),Offset(focus.first*size.width,focus.second*size.height),style=Stroke(1.dp.toPx()))
   }
  }
  Text(if(failure)"이 프레임을 읽을 수 없습니다" else "원본 · 터치로 대상 지정",fontSize=10.sp,color=Color.White,modifier=Modifier.align(Alignment.TopStart).padding(10.dp).background(Color(0xAA101720),RoundedCornerShape(6.dp)).padding(6.dp))
 }
}
