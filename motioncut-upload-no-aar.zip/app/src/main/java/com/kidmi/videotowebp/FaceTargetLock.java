package com.kidmi.videotowebp;

/** Geometric/ID association only. Does not identify people. Coordinates are normalized. */
public final class FaceTargetLock {
    public static int select(float[][] boxes, Integer[] ids, Integer lockedId,
                             float[] lastBox, float tx, float ty) {
        int best = -1;
        float bestDistance = Float.MAX_VALUE, secondDistance = Float.MAX_VALUE;
        float gate = lastBox == null ? .10f : Math.max(.035f, Math.min(.12f,
                Math.max(lastBox[2] - lastBox[0], lastBox[3] - lastBox[1]) * .60f));
        for (int i = 0; i < boxes.length; i++) {
            float[] b = boxes[i];
            if (b[2] <= b[0] || b[3] <= b[1]) continue;
            float distance = (float)Math.hypot((b[0]+b[2])*.5f-tx, (b[1]+b[3])*.5f-ty);
            if (lastBox == null) {
                boolean contains = tx >= b[0] && tx <= b[2] && ty >= b[1] && ty <= b[3];
                if (!contains && distance >= .10f) continue;
            } else {
                float area = (lastBox[2]-lastBox[0]) * (lastBox[3]-lastBox[1]);
                float ratio = (b[2]-b[0]) * (b[3]-b[1]) / Math.max(1e-8f, area);
                if (distance > gate || ratio < .60f || ratio > 1.65f) continue;
                if (lockedId != null && !lockedId.equals(ids[i])) continue;
            }
            if (distance < bestDistance) {
                secondDistance = bestDistance; bestDistance = distance; best = i;
            } else if (distance < secondDistance) secondDistance = distance;
        }
        if (lastBox != null && lockedId == null && secondDistance-bestDistance < .035f) return -1;
        return best;
    }
}
