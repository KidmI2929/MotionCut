package com.kidmi.videotowebp

import kotlin.math.roundToLong

data class StudioCropWindow(val left:Float,val top:Float,val width:Float,val height:Float)

fun studioAspectRatio(aspect:String,c:StudioClip?):Double {
 val parts=aspect.split(":")
 if(parts.size==2){val a=parts[0].toDoubleOrNull();val b=parts[1].toDoubleOrNull();if(a!=null && b!=null && a.isFinite() && b.isFinite() && a>0 && b>0)return (a/b).coerceIn(.1,10.0)}
 return if(c==null)16.0/9 else if(c.rotation%180==0)c.width.toDouble()/c.height.coerceAtLeast(1) else c.height.toDouble()/c.width.coerceAtLeast(1)
}
/** All tracking points use original, display-oriented source coordinates and source timestamps. */
fun StudioClip.sourceTime(outputOffsetMs:Long):Long = (startMs+(outputOffsetMs.coerceAtLeast(0)*speed).roundToLong()).coerceIn(startMs,endMs)
fun StudioClip.timelineTime(sourceMs:Long):Long = ((sourceMs-startMs)/speed.toDouble()).roundToLong().coerceIn(0,outputDurationMs)
fun studioFocus(points:List<FocusKeyframe>,timeMs:Long,x:Float,y:Float):Pair<Float,Float>{
 if(points.isEmpty())return x to y
 if(timeMs<=points.first().timeMs)return points.first().x to points.first().y
 if(timeMs>=points.last().timeMs)return points.last().x to points.last().y
 var low=0;var high=points.lastIndex
 while(high-low>1){val mid=(low+high)/2;if(points[mid].timeMs<=timeMs)low=mid else high=mid}
 val a=points[low];val b=points[high];val t=(timeMs-a.timeMs).toFloat()/(b.timeMs-a.timeMs).coerceAtLeast(1)
 return (a.x+(b.x-a.x)*t) to (a.y+(b.y-a.y)*t)
}
fun StudioClip.trackingPoints()=mergeTrackingKeyframes(autoTrack,manualTrack,0,durationMs)
fun studioCropWindow(c:StudioClip,aspect:String,timeMs:Long,points:List<FocusKeyframe> = c.trackingPoints()):StudioCropWindow{
 if(!c.cropEnabled)return StudioCropWindow(0f,0f,1f,1f)
 var target=studioAspectRatio(aspect,c).toFloat()
 if(c.rotation%180!=0)target=1f/target
 val source=c.width.toFloat()/c.height
 val w=(if(source>target)target/source else 1f)/c.cropZoom
 val h=(if(source>target)1f else source/target)/c.cropZoom
 val(x,y)=studioFocus(points,timeMs,c.focusX,c.focusY)
 return StudioCropWindow((x-w/2).coerceIn(0f,(1f-w).coerceAtLeast(0f)),(y-h/2).coerceIn(0f,(1f-h).coerceAtLeast(0f)),w,h)
}
