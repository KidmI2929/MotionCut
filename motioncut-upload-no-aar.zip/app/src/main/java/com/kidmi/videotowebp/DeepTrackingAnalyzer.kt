package com.kidmi.videotowebp

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.Rect
import org.opencv.imgproc.Imgproc
import org.opencv.video.TrackerVit
import org.opencv.video.TrackerVit_Params
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.*

data class DeepTrackResult(val points:List<FocusKeyframe>,val lostAtMs:Long?,val minimumScore:Float)
class DeepTrackingAnalyzer(private val context:Context){
 companion object{private val executor=Executors.newSingleThreadExecutor()}
 private val generation=AtomicInteger()
 private val main=Handler(Looper.getMainLooper())
 fun cancel(){generation.incrementAndGet()}
 fun analyze(clip:StudioClip,startMs:Long,onStatus:(String)->Unit,onProgress:(Float)->Unit,onComplete:(DeepTrackResult)->Unit,onError:(String)->Unit){
  val token=generation.incrementAndGet()
  fun post(block:()->Unit){main.post{if(generation.get()==token)block()}}
  executor.execute{
   val r=MediaMetadataRetriever();var rgba:Mat?=null;var bgr:Mat?=null
   try{
    require(clip.targetSelected){"먼저 대상 중심을 터치하고 선택 영역을 맞춰 주세요."}
    check(OpenCVLoader.initLocal()){ "추적 엔진을 불러올 수 없습니다." };Core.setNumThreads(2)
    val color=Mat();val frame=Mat();rgba=color;bgr=frame
    val model=File(context.filesDir,"tracking/vittrack.onnx");model.parentFile?.mkdirs()
    if(!model.exists() || model.length()!=context.assets.open("tracking/vittrack.onnx").use{it.available().toLong()}){
     val temporary=File(model.parentFile,"vittrack.tmp");context.assets.open("tracking/vittrack.onnx").use{input->temporary.outputStream().use{input.copyTo(it)}}
     check(temporary.renameTo(model)){"추적 모델 저장 실패"}
    }
    val parameters=TrackerVit_Params().apply{set_net(model.absolutePath);set_tracking_score_threshold(.55f)}
    val tracker=TrackerVit.create(parameters)
    r.setDataSource(context,Uri.parse(clip.uri))
    val points=mutableListOf<FocusKeyframe>();var old:Rect?=null;var anchor:FloatArray?=null
    var lost:Long?=null;var minimum=1f;var sx=clip.focusX;var sy=clip.focusY
    val start=startMs.coerceIn(clip.startMs,clip.endMs-100);var time=start
    while(time<clip.endMs){
     if(generation.get()!=token)return@execute
     val bitmap=r.getScaledFrameAtTime(time*1000,MediaMetadataRetriever.OPTION_CLOSEST,640,640)
      ?: throw IllegalArgumentException("${formatDetailedTime(time)} 프레임을 읽을 수 없습니다.")
     try{
      Utils.bitmapToMat(bitmap,color);Imgproc.cvtColor(color,frame,Imgproc.COLOR_RGBA2BGR)
      val w=frame.cols();val h=frame.rows()
      if(old==null){
       val side=(min(w,h)*clip.targetSize).roundToInt().coerceAtLeast(12)
       val box=Rect((clip.focusX*w-side/2).roundToInt().coerceIn(0,w-side),(clip.focusY*h-side/2).roundToInt().coerceIn(0,h-side),side,side)
       anchor=histogram(frame,box);tracker.init(frame,box);old=box
       sx=(box.x+box.width/2f)/w;sy=(box.y+box.height/2f)/h
      }else{
       val box=Rect();val ok=tracker.update(frame,box);val score=tracker.trackingScore;minimum=min(minimum,score)
       val previous=old!!;val x=(box.x+box.width/2f)/w;val y=(box.y+box.height/2f)/h
       val inBounds=box.x>=0 && box.y>=0 && box.width>1 && box.height>1 && box.x+box.width<=w && box.y+box.height<=h
       val distance=if(inBounds)distance(anchor!!,histogram(frame,box)) else 1f
       if(!ok || !inBounds || !TrackingGuard.accept(score,(previous.x+previous.width/2f)/w,(previous.y+previous.height/2f)/h,x,y,(previous.width*previous.height).toFloat(),(box.width*box.height).toFloat(),distance)){
        lost=time;points+=FocusKeyframe(time,sx,sy);points+=FocusKeyframe(clip.endMs,sx,sy);break
       }
       old=box;sx+=.65f*(x-sx);sy+=.65f*(y-sy)
      }
      points+=FocusKeyframe(time,sx,sy)
     }finally{bitmap.recycle()}
     val current=time
     post{onProgress((current-start).toFloat()/(clip.endMs-start));onStatus("AI 대상 추적 · ${formatDetailedTime(current)} / ${formatDetailedTime(clip.endMs)}")}
     time+=100
    }
    if(points.isNotEmpty() && points.last().timeMs<clip.endMs)points+=FocusKeyframe(clip.endMs,sx,sy)
    post{onProgress(1f);onComplete(DeepTrackResult(points,lost,minimum))}
   }catch(e:Throwable){post{onError("대상 추적 실패: ${e.message ?: e.javaClass.simpleName}")}}
   finally{runCatching{r.release()};rgba?.release();bgr?.release()}
  }
 }
 private fun histogram(image:Mat,box:Rect):FloatArray{
  val values=FloatArray(48);val bytes=ByteArray(3)
  val step=max(1,min(box.width,box.height)/20);var samples=0
  for(y in box.y until box.y+box.height step step)for(x in box.x until box.x+box.width step step){
   image.get(y,x,bytes);for(c in 0..2)values[c*16+((bytes[c].toInt() and 255)/16)]++;samples++
  }
  for(i in values.indices)values[i]/=(samples*3).coerceAtLeast(1)
  return values
 }
 private fun distance(a:FloatArray,b:FloatArray):Float=a.indices.sumOf{abs(a[it]-b[it]).toDouble()}.toFloat()/2
}
