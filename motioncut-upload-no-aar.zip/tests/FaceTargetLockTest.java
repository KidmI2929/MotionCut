import com.kidmi.videotowebp.FaceTargetLock;
public class FaceTargetLockTest {
 static float[] box(float x,float y,float size){return new float[]{x-size/2,y-size/2,x+size/2,y+size/2};}
 static void expect(int value,int wanted,String why){if(value!=wanted)throw new AssertionError(why+": "+value);}
 public static void main(String[] args){
  float[] original=box(.3f,.5f,.2f);
  expect(FaceTargetLock.select(new float[][]{box(.6f,.5f,.5f),original},new Integer[]{2,1},null,null,.3f,.5f),1,"tap wins over larger neighbor");
  expect(FaceTargetLock.select(new float[][]{box(.33f,.5f,.2f),box(.31f,.5f,.2f)},new Integer[]{2,1},1,original,.3f,.5f),1,"ID wins when faces near");
  expect(FaceTargetLock.select(new float[][]{box(.32f,.5f,.2f)},new Integer[]{2},1,original,.3f,.5f),-1,"lost ID cannot switch");
  expect(FaceTargetLock.select(new float[][]{box(.8f,.5f,.2f)},new Integer[]{1},1,original,.3f,.5f),-1,"ID teleport rejected");
  expect(FaceTargetLock.select(new float[][]{box(.31f,.5f,.5f)},new Integer[]{1},1,original,.3f,.5f),-1,"sudden size change rejected");
  expect(FaceTargetLock.select(new float[][]{box(.28f,.5f,.2f),box(.32f,.5f,.2f)},new Integer[]{null,null},null,original,.3f,.5f),-1,"ambiguous ID-free match holds");
  expect(FaceTargetLock.select(new float[][]{},new Integer[]{},1,original,.3f,.5f),-1,"empty detection holds");
  System.out.println("PASS: tap, nearby faces, ID loss, teleport, scale, ambiguous candidates, empty detections");
 }
}
