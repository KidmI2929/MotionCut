package com.kidmi.videotowebp
import kotlin.test.Test
import kotlin.test.assertEquals
class StudioColorMappingTest {
 @Test fun uiBrightnessNeutralAndLimits(){ assertEquals(0f, 0f/200f); assertEquals(.5f,100f/200f); assertEquals(-.5f,-100f/200f) }
 @Test fun saturationUsesPercentUnits(){ assertEquals(100f,100f.coerceIn(-100f,100f)); assertEquals(-100f,(-150f).coerceIn(-100f,100f)) }
}
