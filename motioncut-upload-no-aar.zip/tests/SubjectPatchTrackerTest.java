import com.kidmi.videotowebp.SubjectPatchTracker;
import java.util.Arrays;
import java.util.Random;

public class SubjectPatchTrackerTest {
    static final int W = 200, H = 200;
    static int[] frame(int x, int y, boolean visible, int otherX) {
        int[] p = new int[W * H]; Arrays.fill(p, 0xff303030);
        if (visible) draw(p, x, y, 12, false);
        if (otherX >= 0) draw(p, otherX, y, 77, true);
        return p;
    }
    static void draw(int[] p, int cx, int cy, int seed, boolean white) {
        Random r = new Random(seed);
        for (int y = -25; y <= 25; y++) for (int x = -25; x <= 25; x++) {
            int v = 50 + r.nextInt(140);
            p[(cy+y)*W+cx+x] = 0xff000000 | (v+35)<<16 | v<<8 | (white?v:v/2);
        }
    }
    static void require(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    public static void main(String[] args) {
        SubjectPatchTracker t = new SubjectPatchTracker();
        require(t.initialize(frame(70,100,true,145),W,H,.35f,.5f),"seed");
        for (int i=0; i<10; i++) {
            float[] stable = t.update(frame(70,100,true,145),W,H);
            require(stable != null && Math.abs(stable[0]*W-70)<.1f,"static subject must not drift");
        }
        for (int x = 72; x <= 90; x += 2) {
            float[] result = t.update(frame(x,100,true,145),W,H);
            require(result != null && Math.abs(result[0]*W-x)<3,"follow selected at "+x);
        }
        require(t.update(frame(90,100,false,115),W,H)==null,"must hold on disappearance with neighbor");
        float[] returned = t.update(frame(92,100,true,150),W,H);
        require(returned!=null && Math.abs(returned[0]*W-92)<3,"reacquire original appearance nearby");
        int[] blank = new int[W*H]; Arrays.fill(blank,0xff888888);
        require(t.update(blank,W,H)==null,"blank frame hold");
        require(!new SubjectPatchTracker().initialize(blank,W,H,.5f,.5f),"reject featureless seed");
        require(!new SubjectPatchTracker().initialize(frame(70,100,true,145),W,H,.01f,.01f),"reject border seed");
        int[] seed = new int[W*H]; Arrays.fill(seed,0xff303030);
        int[] twins = seed.clone();
        Random random = new Random(31);
        for (int yy=-21; yy<=21; yy++) for (int xx=-21; xx<=21; xx++) {
            int color = 0xff000000 | random.nextInt(0xffffff);
            seed[(100+yy)*W+100+xx] = color;
            twins[(100+yy)*W+78+xx] = color;
            twins[(100+yy)*W+122+xx] = color;
        }
        SubjectPatchTracker a = new SubjectPatchTracker();
        require(a.initialize(seed,W,H,.5f,.5f),"ambiguous seed");
        require(a.update(twins,W,H)==null,"identical distant matches hold");
        require(t.update(new int[100],10,10)==null,"dimension change holds");
        System.out.println("PASS: movement, neighbor, occlusion, return, blank, seed bounds, ambiguity, dimensions");
    }
    static void drawSmall(int[] p,int x,int y) {
        Random r=new Random(12);
        for(int j=-20;j<=20;j++) for(int i=-20;i<=20;i++) p[(y+j)*W+x+i]=0xff000000|r.nextInt(0xffffff);
    }
}
