# Motion WebP 1.3.2

- Face mode: only acquire near the selected point; remove large-face bias. Keep the locked tracking ID, reject implausible distance/size changes, and hold when it disappears instead of switching IDs.
- New Subject/Animal mode: bounded RGB patch matching at up to 320px; compare both immutable starting appearance and slowly updated appearance. Reject ambiguous, low-confidence, border and featureless matches. Hold position on loss. No face recognition is used in this mode.
- Reduce per-sample crop jumps and invalidate an in-flight preview when its focus/mode/clip changes.
- Selecting a tracking mode pauses and seeks to the clip start so the initial target can be chosen there. Use Crop controls, tap the subject center, then Analyze.
- Same stable application ID and restored signing certificate as 1.3.1; versionCode 21.

## Limits
The supplied WebP contains one frame, not the source motion sequence. Face association tests cover tap priority, adjacent faces, lost IDs, large jumps, size changes and ambiguous detections. Synthetic appearance tests check motion, neighboring subjects, occlusion, return, blank frames, ambiguous matches and dimensions. They do not establish real-device performance or accuracy on the original video. Fast motion, strong rotation, scene cuts and large appearance changes may hold instead of following. Correct those segments using existing manual keyframes. Face ID changes intentionally hold rather than acquiring a different person.
