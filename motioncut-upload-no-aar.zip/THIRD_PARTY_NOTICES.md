# Third-party notices

This application uses open-source multimedia components. The repository's GitHub Actions workflow
builds the native multimedia engine from public source.

## FFmpegKit maintained fork

Source: https://github.com/ffmpegkit-maintained/ffmpeg

The Android wrapper and related FFmpegKit components are distributed under the GNU Lesser General
Public License as described by the upstream project. The custom build used by this app is produced
by the workflow in `.github/workflows/build-apk.yml`.

## FFmpeg

Source: https://ffmpeg.org/ and https://github.com/FFmpeg/FFmpeg

The custom configuration used by this app does not enable FFmpeg's GPL option. It enables libwebp,
Android MediaCodec support, shared libraries, and ARM64/NEON optimizations.

## libwebp

Source: https://chromium.googlesource.com/webm/libwebp/ and https://github.com/webmproject/libwebp

libwebp is the WebP codec library used for Animated WebP encoding.

## Termux

Reference source: https://github.com/termux/termux-packages

The Termux FFmpeg package build script was consulted as a public reference for Android FFmpeg build
configuration and performance-oriented features. Termux source code is not bundled into this app.

## MotionCut 2.0 additions
AndroidX Media3 Transformer, Effect and Common 1.11.1: Apache License 2.0, obtained from Google's official Maven repository. Source: https://github.com/androidx/media
The MotionCut launcher vector is an original design. Captions use Android system fonts. CapCut, VN and InShot public feature pages were used as product-flow references; no competitor artwork or proprietary source was copied.

## MotionCut 2.2
OpenCV Android 4.13.0 and OpenCV Zoo ViTTrack: Apache 2.0.
Model: https://github.com/opencv/opencv_zoo/tree/main/models/object_tracking_vittrack
The official object_tracking_vittrack_2023sep.onnx is packaged in app/src/main/assets/tracking/vittrack.onnx. The model license is included in licenses/ViTTrack-Apache-2.0.txt.
The duplicated libc++_shared.so was removed from the custom FFmpeg AAR so all native libraries use the C++ runtime distributed with OpenCV. FFmpeg codec libraries were not changed.
