# Motion WebP 1.3.1 — scroll interaction fix

- Both edit and tracking previews now start with crop interaction disabled.
- Tap/pan/pinch recognizers are installed but do not handle events unless the visible Crop interaction switch is enabled. Vertical drags therefore remain available to the parent vertical scroll container in the default mode.
- Turning crop interaction on enables the existing crop tap/drag/pinch behavior. The switch is above each preview; switching it off returns to scrolling.
- Scroll containers fill the entire available width.
- Native media binaries and conversion behavior are unchanged from v1.3.

Package: com.kidmi.videotowebp.stable; versionCode 20; versionName 1.3.1.
The previous temporary workspace and debug signing key were unavailable. This package is installed alongside v1.3 instead of requiring its removal. The new signing key has a separate private build-continuity backup, not included in this source archive.

Validation: compile, package version, APK signature and archive integrity. Physical-device touch behavior has not been tested in this environment.
