# Motion WebP 1.3.0

## Changes
- Move conversion preparation and input-file copying off the UI thread.
- Check the operation generation during file copying and remove incomplete cache files on failure/cancellation.
- Gate conversion UI callbacks by generation to avoid stale updates after cancellation or video changes.
- Limit FFmpeg decoder/encoder threads to 2 and filter threads to 1 to reduce parallel resource use.
- Serialize tracking jobs; catch detector-initialization failures and release detectors.
- Remove full-resolution frame fallback in tracking and timeline thumbnails.
- Serialize thumbnail decoding, check cancellation between frames, and show an unavailable message after failure.
- Decode result WebP previews off the UI thread at a maximum side of 640 pixels; stop animation and detach views on disposal.
- Detach obsolete PlayerView surfaces, pause playback when backgrounded, and display playback errors.
- Save uncaught Java/Kotlin errors locally and offer copyable diagnostics on the next launch. Android 11+ can also report OS-recorded crash/ANR/low-memory exit reasons. Native failures on Android 10 may not produce this report. No automatic report upload.

## Build and limits
- versionCode 19; versionName 1.3.0; package com.kidmi.videotowebp.local123.
- Same signing certificate as the delivered local v1.2.3/v1.2.4; installs as an update to those builds.
- Compiled with Java 17, Gradle 8.11.1, Android SDK 36 and Build Tools 35.
- app/libs/ffmpeg-kit-custom.aar is included for reproducible dependency resolution. It uses the Java wrapper from dev.ffmpegkit-maintained:ffmpeg-kit-full-gpl:8.1.7 and ARM64 native libraries from the user's v1.2.2 APK. Native-library hashes were checked against that APK. Runtime wrapper/native compatibility has not been device-tested.
- assembleDebug, APK signature verification, ZIP integrity and libwebp presence checks passed.
- No physical-device or emulator run was available. This release is not proof that the reported crash is resolved; its next-launch diagnostics are intended to narrow the remaining cause.
- Signing private keys are not included. A fresh local build uses its own debug key.
